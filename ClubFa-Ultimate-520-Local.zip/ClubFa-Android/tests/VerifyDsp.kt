import com.clubfa.app.*
import kotlin.math.*

fun main() {
    require(PresetCatalog.all.size==520)
    require(PresetCatalog.all.map{it.id}.toSet().size==520)
    require(PresetCatalog.all.map{it.name}.toSet().size==520)
    val configs=PresetCatalog.all.map { listOf(it.cutoff,it.echoMs,it.feedback,it.room,it.bass,it.width,it.modHz,it.movement,it.distortion,it.highpass) }
    require(configs.toSet().size==520) { "Presets precisam variar seus parâmetros" }
    val input=ShortArray(4096){ i-> (sin(i*.052)*17000).roundToInt().toShort() }
    val orig=input.copyOf()
    val results=mutableSetOf<Int>()
    for(p in PresetCatalog.all) {
        val dsp=Dsp()
        dsp.preset=p.id
        val buffer=orig.copyOf()
        dsp.process(buffer,buffer.size)
        require(buffer.any { it.toInt()!=0 }) {"Saída zerada: ${p.id}"}
        results.add(buffer.contentHashCode())
    }
    check(results.size>=300){ "Presets produzem muitas saídas idênticas: ${results.size}" }
    val engine=Dsp()
    engine.bypass=true
    val copy=orig.copyOf();engine.process(copy,copy.size)
    require(copy.any{it.toInt()!=0})
    println("OK: ${PresetCatalog.all.size} presets, ${results.size} saídas PCM distintas, bypass e limites verificados")
}
