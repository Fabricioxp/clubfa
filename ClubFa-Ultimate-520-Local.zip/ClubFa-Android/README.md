# ClubFa Ultimate Local — código Android

Este é um aplicativo Android nativo feito em Kotlin, sem Firebase, sem servidor, sem banco remoto, sem conexão obrigatória e sem permissão `INTERNET` no manifesto. Usa exclusivamente APIs do Android e o plugin Kotlin/Gradle para compilar. **Não contém uma senha fixa.**

## O que está implementado neste pacote

- Criação da conta local e bloqueio por e-mail/senha, verificador PBKDF2-HMAC-SHA256 com salt aleatório (210 mil iterações); alterar senha (sem recuperação por e-mail).
- **520 presets de áudio concretos**, derivados de 20 ambientes acústicos com 24 configurações cada + 40 receitas LAB. Todos alteram variáveis reais do DSP e podem ser ouvidos ao reproduzir arquivo local. Não confundir esses 520 presets com a implementação das 520 ideias de produto discutidas anteriormente.
- DSP estéreo PCM16 em tempo real, filtro low-pass/high-pass, 3 bandas básicas de EQ, controle de graves, reverb/echo, feedback, panorama em movimento, largura estéreo, distorção suave, porta acústica simulada, distância, bypass e mono.
- Player local usando `MediaExtractor`/`MediaCodec` com decodificadores do próprio telefone (MP3, M4A/AAC, FLAC, OGG, WAV e outros formatos **quando suportados pelo Android no dispositivo**).
- Importar vários arquivos pelo seletor Android; biblioteca persistente com título, artista, duração, busca, favoritos, contagem de reproduções e ordem dos arquivos; play/pause/stop/próxima faixa.
- Exportação do áudio com efeitos aplicados para WAV estéreo PCM16; criação de arquivo pelo seletor do Android.
- Gravação de microfone WAV mono para arquivos privados do app; adição de gravações à biblioteca.
- Perfis próprios do estúdio; favoritos de presets; backup/restauração JSON de configurações, referências de biblioteca e perfis (não inclui áudio nem senha).
- Captura de reprodução Android `MediaProjection` para apps que permitem, herdada do projeto original. **Não** funciona com fontes que bloqueiem a captura. Não remove o áudio direto da fonte: evite duplicações de som e use fones.
- Geração offline de uma música de demonstração de 12 segundos para testar os efeitos sem arquivos externos.
- Interface nativa escura com 5 seções: Início, Ambientes, Estúdio, Biblioteca e Conta.

## Funcionalidades NÃO implementadas

Este pacote **não** implementa as 520 ideias de produto individualmente (por exemplo HRTF real, masterização LUFS, Android Auto, autenticação multifator, comunidade online, IA de linguagem, detecção de BPM, equalizador de 31 bandas, conversão para MP3, time stretch/pitch shift, serviços em nuvem, visualizador FFT, MediaSession ou execução do player em segundo plano). O pedido de funcionamento inteiramente local elimina ou transforma algumas ideias que dependem de serviço remoto. A presença de **520 presets acústicos não equivale a 520 funções independentes**.

## Passo a passo pelo celular / GitHub

1. **Pelo celular (mais fácil):** envie `ClubFa-Ultimate-520-Local.zip` para a raiz do repositório GitHub, sem descompactar. Você também pode extrair o conteúdo e enviar `app/`, `settings.gradle.kts` etc. para a raiz.
2. Abra `.github/workflows/build-apk.yml` e substitua pelo arquivo `build-clubfa-ultimate-520.yml` fornecido separadamente. O workflow aceita tanto código extraído quanto ZIP.
3. Em GitHub → **Actions** → **ClubFa Ultimate - Gerar APK** → **Run workflow**.
4. Aguarde o build; em **Artifacts** baixe `ClubFa-Ultimate-APK`.
5. Instale no Android 10+ e crie uma **senha nova** na primeira inicialização. Para atualizar por cima do APK anterior, ele precisa estar assinado pela mesma chave; builds debug do GitHub normalmente usam chaves diferentes e podem exigir desinstalação. Faça backup das configurações antes.

## Segurança

O login é uma **barreira local de interface**, não autenticação remota resistente a acesso físico privilegiado/root. Não reutilize senha de outras contas. O usuário que desinstalar o app ou apagar os dados poderá criar outra identidade local. Exportações JSON não contêm senha mas podem conter nomes e URIs de arquivos.

## Build e testes

- `gradle :app:assembleDebug` (Android SDK 35, Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3).
- Teste do motor de áudio puro (sem Android): `kotlinc app/src/main/java/com/clubfa/app/{PresetCatalog,Dsp}.kt tests/VerifyDsp.kt -include-runtime -d tests/verify.jar && java -jar tests/verify.jar`
- O workflow do GitHub compila o APK. É preciso instalar e testar no telefone, porque suporte de codecs e captura variam conforme dispositivo e apps.

## Limitações operacionais

- Áudio de Spotify/YouTube pode bloquear captura; não existe contorno implementado.
- O player é centrado na Activity; sair/fechar interrompe a reprodução local. Não há serviço dedicado de player em segundo plano.
- Em exportações longas, o WAV temporário ocupa espaço no armazenamento em cache; arquivos superiores a ~3,8 GB são recusados.
- URI de arquivo selecionado pode expirar após desinstalação; restaure músicas pela biblioteca.
- O ClubFa não foi submetido à Play Store nem certificado para todos os fabricantes Android.
