package com.clubfa.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.concurrent.thread
import kotlin.math.*

/** A real local Android app: authentication gate, library, 520 DSP presets, editor, capture and export. */
class MainActivity : Activity() {
    private val bg=Color.rgb(12,8,23)
    private val surface=Color.rgb(28,20,45)
    private val surfaceLight=Color.rgb(42,29,67)
    private val purple=Color.rgb(176,120,255)
    private val secondary=Color.rgb(130,87,213)
    private val muted=Color.rgb(190,177,208)
    private val dsp get()=CaptureService.dsp
    private val prefs by lazy { getSharedPreferences("clubfa_controls",MODE_PRIVATE) }
    private val auth by lazy { LocalAuth(this) }
    private val library by lazy { LocalLibrary(this) }
    private val player by lazy { LocalAudioEngine(this,dsp) { status=it; if(unlocked && activePage=="Início") drawPage() } }
    private val recorder by lazy { MicrophoneRecorder(this) }
    private val handler=Handler(Looper.getMainLooper())
    private var unlocked=false
    private var activePage="Início"
    private var status="Escolha uma música para começar"
    private var displayedPeak:TextView?=null
    private var selectedMusic:String?=null
    private var exportUri:Uri?=null
    private var presetSearch=""
    private var presetCategory="Todas"
    private var presetPage=0
    private var librarySearch=""
    private var favoritesOnly=false
    private val REQUEST_PICK=101
    private val REQUEST_CAPTURE=102
    private val REQUEST_CAPTURE_PERMISSION=103
    private val REQUEST_MIC=104
    private val REQUEST_EXPORT=105
    private val REQUEST_BACKUP=106
    private val REQUEST_RESTORE=107
    private val pages=listOf("Início","Ambientes","Estúdio","Biblioteca","Conta")
    private val settings=listOf("intensity","bass","wet","output","tone","stereo","movement","distortion","door","distance","eqLow","eqMid","eqHigh")
    private val peakUpdater=object:Runnable {
        override fun run() {
            if(unlocked) {
                val level=(dsp.peak*100).toInt().coerceIn(0,100)
                displayedPeak?.text="${"▮".repeat((level/7).coerceIn(0,14))}${"▯".repeat((14-level/7).coerceIn(0,14))}  $level%"
                handler.postDelayed(this,160)
            }
        }
    }
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=bg;window.navigationBarColor=bg
        loadControls();showLogin()
    }
    override fun onDestroy() {
        unlocked=false
        handler.removeCallbacks(peakUpdater)
        player.stop()
        if(recorder.running) recorder.stop()
        super.onDestroy()
    }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    private fun shape(c:Int,r:Int=18):GradientDrawable=GradientDrawable().apply {setColor(c);cornerRadius=dp(r).toFloat()}
    private fun txt(t:String,s:Float=14f,color:Int=Color.WHITE,bold:Boolean=false):TextView=TextView(this).apply {
        text=t;textSize=s;setTextColor(color);if(bold)setTypeface(null,Typeface.BOLD)
        setPadding(dp(3),dp(5),dp(3),dp(5))
    }
    private fun vertical(pad:Int=0):LinearLayout=LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL
        if(pad>0)setPadding(dp(pad),dp(pad),dp(pad),dp(pad))
    }
    private fun horizontal():LinearLayout=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL }
    private fun add(v:LinearLayout, child:View, height:Int=0, bottom:Int=0) {
        v.addView(child, LinearLayout.LayoutParams(-1,if(height>0) dp(height) else -2).apply {bottomMargin=dp(bottom)})
    }
    private fun btn(t:String,color:Int=secondary,action:()->Unit):Button=Button(this).apply {
        text=t;isAllCaps=false;textSize=13f;setTextColor(Color.WHITE)
        background=shape(color,12)
        setPadding(dp(9),dp(7),dp(9),dp(7))
        setOnClickListener { action() }
    }
    private fun small(t:String,action:()->Unit)=btn(t,surfaceLight,action)
    private fun rowButtons(parent:LinearLayout, vararg actions:Pair<String,()->Unit>) {
        val row=horizontal()
        actions.forEach { (title,fn) ->
            val b=small(title,fn)
            row.addView(b,LinearLayout.LayoutParams(0,dp(48),1f).apply {marginEnd=dp(5)})
        }
        add(parent,row,bottom=7)
    }
    private fun card(parent:LinearLayout,title:String,sub:String=""):LinearLayout {
        val container=vertical(15);container.background=shape(surface)
        add(container,txt(title,19f,Color.WHITE,true))
        if(sub.isNotBlank()) add(container,txt(sub,12f,muted),bottom=9)
        add(parent,container,bottom=12)
        return container
    }
    private fun field(hint:String,initial:String="",password:Boolean=false):EditText=EditText(this).apply {
        this.hint=hint;setText(initial);setTextColor(Color.WHITE);setHintTextColor(muted)
        textSize=14f;background=shape(surfaceLight,10)
        setPadding(dp(13),dp(12),dp(13),dp(12));setSingleLine(true)
        inputType=if(password) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                  else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
    }
    private fun scrollPage():LinearLayout {
        displayedPeak=null
        val scroll=ScrollView(this).apply {isFillViewport=true;setBackgroundColor(bg);fillViewportCompat()}
        val root=vertical(16)
        scroll.addView(root)
        setContentView(scroll)
        return root
    }
    private fun ScrollView.fillViewportCompat() { isFillViewport=true }
    private fun showLogin() {
        unlocked=false;handler.removeCallbacks(peakUpdater)
        val root=scrollPage()
        root.setPadding(dp(24),dp(55),dp(24),dp(25))
        add(root,txt("◈ ClubFa",36f,purple,true))
        add(root,txt("ULTIMATE · LOCAL AUDIO STUDIO",12f,muted,true),bottom=22)
        val first=!auth.registered
        val box=card(root,if(first)"Criar acesso local" else "Bem-vindo de volta",
            if(first)"Sua identidade ficará somente neste aparelho." else "Entre com seus dados locais para abrir seu estúdio.")
        val email=field("E-mail",if(first)"Fabricio.campos1566@gmail.com" else auth.email)
        val pw=field("Senha (mínimo 10 caracteres)",password=true)
        add(box,email,bottom=8);add(box,pw,bottom=11)
        if(first) add(box,txt("Crie uma senha NOVA. Ela nunca será escrita no projeto nem enviada para servidores. O acesso local não oferece recuperação por e-mail.",12f,muted))
        add(box,btn(if(first)"Criar acesso e entrar" else "Entrar",secondary) {
            val e=email.text.toString().trim();val p=pw.text.toString()
            if(first) {
                if(auth.create(e,p)) {unlocked=true;activePage="Início";drawPage()}
                else toast("Use e-mail válido e senha de pelo menos 10 caracteres")
            } else {
                if(auth.verify(e,p)) {unlocked=true;activePage="Início";drawPage()}
                else toast("E-mail ou senha incorretos")
            }
        },bottom=6)
        add(root,txt("Sem Firebase · Sem conta online · Seus arquivos continuam no celular.",12f,muted))
    }
    private fun drawPage() {
        if(!unlocked)return
        handler.removeCallbacks(peakUpdater)
        val root=scrollPage()
        add(root,txt("◈ ClubFa",30f,purple,true))
        add(root,txt("ULTIMATE   /   ÁUDIO LOCAL",11f,muted,true),bottom=10)
        val tabs=horizontal()
        pages.forEach { p ->
            val b=btn(if(p==activePage) "● ${p.take(4)}" else p.take(4),if(p==activePage)secondary else surfaceLight) {
                activePage=p;drawPage()
            }
            b.textSize=11f
            tabs.addView(b,LinearLayout.LayoutParams(0,dp(45),1f).apply {marginEnd=dp(3)})
        }
        add(root,tabs,bottom=12)
        when(activePage) {
            "Início"->home(root)
            "Ambientes"->presetBrowser(root)
            "Estúdio"->studio(root)
            "Biblioteca"->musicLibrary(root)
            "Conta"->account(root)
        }
        add(root,txt("ClubFa Ultimate Local · ${PresetCatalog.all.size} presets DSP · sem servidor",11f,muted))
        handler.post(peakUpdater)
    }
    private fun home(root:LinearLayout) {
        val hero=card(root,"Sua música. Seu universo.","520 configurações sonoras utilizáveis pelo processamento local do ClubFa.")
        add(hero,txt("AMBIENTE SELECIONADO",11f,purple,true))
        add(hero,txt(PresetCatalog.byId(dsp.preset).name,18f,Color.WHITE,true))
        rowButtons(hero,"Trocar ambiente" to {activePage="Ambientes";drawPage()},"Editar som" to {activePage="Estúdio";drawPage()})
        val audio=card(root,"Player local","MP3, M4A, WAV, FLAC, OGG e outros formatos com decodificador Android.")
        add(audio,txt(if(player.isPlaying) "♪ ${player.current}" else status,14f,purple))
        rowButtons(audio,"▶ Tocar seleção" to {playSelected()},"⏯ Pausar/Voltar" to {player.pauseOrResume()})
        rowButtons(audio,"⏹ Parar" to {player.stop()},"⏭ Próxima" to {playNext()})
        rowButtons(audio,"+ Adicionar músicas" to {pickMusic()},"Biblioteca" to {activePage="Biblioteca";drawPage()})
        add(audio,small("♫ Criar música de demonstração (offline)") {
            thread(name="ClubFa-Demo") {
                try {
                    val file=DemoAudio.create(this)
                    runOnUiThread {val item=library.add(Uri.fromFile(file));play(item)}
                } catch(e:Exception) {runOnUiThread {toast("Erro ao gerar demonstração: ${e.localizedMessage}")}}
            }
        },bottom=5)
        val meter=card(root,"Monitor de saída","Medidor derivado do áudio processado (estimativa de pico).")
        displayedPeak=txt("▯▯▯▯▯▯▯▯▯▯▯▯▯▯  0%",15f,purple,true)
        add(meter,displayedPeak!!)
        val statusCard=card(root,"Captura de áudio permitida","Somente apps que autorizam captura Android. Spotify e YouTube podem bloquear; captura não remove o áudio original.")
        add(statusCard,txt(if(CaptureService.active)"● ${CaptureService.status}" else "○ Desligada",13f,muted))
        rowButtons(statusCard,"Iniciar captura" to {startCapture()},"Parar captura" to {stopCapture()})
        add(root,txt("Dica: para ouvir o efeito sem duplicação, use os arquivos no player local.",12f,muted))
    }
    private fun presetBrowser(root:LinearLayout) {
        val box=card(root,"520 ambientes para explorar","20 espaços × 24 variações + 40 presets LAB, todos aplicados ao DSP.")
        val query=field("Pesquisar nome ou efeito",presetSearch).apply {
            inputType=InputType.TYPE_CLASS_TEXT;setSingleLine(true)
        }
        add(box,query,bottom=7)
        val choices=listOf("Todas","★ Favoritos")+PresetCatalog.categories
        val spinner=Spinner(this)
        val adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,choices)
        spinner.adapter=adapter
        spinner.setSelection(choices.indexOf(presetCategory).coerceAtLeast(0))
        add(box,spinner)
        val stats=txt("",12f,muted);add(box,stats)
        val listing=vertical()
        add(box,listing)
        val footer=horizontal();add(box,footer)
        fun rebuild() {
            listing.removeAllViews();footer.removeAllViews()
            val favs=prefs.getStringSet("preset_favorites",emptySet()) ?: emptySet()
            val filtered=PresetCatalog.all.filter { p ->
                (presetCategory=="Todas" || (presetCategory=="★ Favoritos" && favs.contains(p.id.toString())) || p.category==presetCategory) &&
                    p.name.contains(presetSearch,ignoreCase=true)
            }
            val pagesCount=max(1,(filtered.size+39)/40)
            presetPage=presetPage.coerceIn(0,pagesCount-1)
            stats.text="${filtered.size} disponíveis · página ${presetPage+1}/$pagesCount"
            filtered.drop(presetPage*40).take(40).forEach { item ->
                val row=horizontal()
                val label=btn((if(dsp.preset==item.id)"● " else "")+item.name,
                    if(dsp.preset==item.id) secondary else surfaceLight) {
                    dsp.preset=item.id;saveControls();toast("Ativo: ${item.name}");rebuild()
                }
                label.gravity=Gravity.CENTER_VERTICAL or Gravity.START
                row.addView(label,LinearLayout.LayoutParams(0,dp(52),1f))
                val star=small(if(favs.contains(item.id.toString()))"★" else "☆") {
                    val set=(prefs.getStringSet("preset_favorites",emptySet())?:emptySet()).toMutableSet()
                    if(!set.add(item.id.toString()))set.remove(item.id.toString())
                    prefs.edit().putStringSet("preset_favorites",set).apply();rebuild()
                }
                row.addView(star,LinearLayout.LayoutParams(dp(52),dp(52)).apply {marginStart=dp(5)})
                add(listing,row,bottom=5)
            }
            val prev=small("← Anterior") {if(presetPage>0){presetPage--;rebuild()}}
            val next=small("Próxima →") {if(presetPage<pagesCount-1){presetPage++;rebuild()}}
            footer.addView(prev,LinearLayout.LayoutParams(0,dp(46),1f).apply {marginEnd=dp(5)})
            footer.addView(next,LinearLayout.LayoutParams(0,dp(46),1f))
        }
        query.addTextChangedListener(object:TextWatcher {
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){presetSearch=s.toString();presetPage=0;rebuild()}
            override fun afterTextChanged(s:Editable?){}
        })
        spinner.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long) {
                val current=choices[position]
                if(current!=presetCategory){presetCategory=current;presetPage=0;rebuild()}
            }
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?){}
        }
        rebuild()
    }
    private fun slider(parent:LinearLayout,label:String,value:Float,changed:(Float)->Unit) {
        val current=txt("$label  ·  ${(value*100).toInt()}%",13f,Color.WHITE)
        add(parent,current)
        val seek=SeekBar(this).apply {
            max=100;progress=(value*100).roundToInt().coerceIn(0,100)
            progressTintList=ColorStateList.valueOf(purple)
            thumbTintList=ColorStateList.valueOf(purple)
        }
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb:SeekBar?,progress:Int,fromUser:Boolean) {
                if(fromUser){changed(progress/100f);current.text="$label  ·  $progress%";saveControls()}
            }
            override fun onStartTrackingTouch(sb:SeekBar?){}
            override fun onStopTrackingTouch(sb:SeekBar?){}
        })
        add(parent,seek,bottom=4)
    }
    private fun studio(root:LinearLayout) {
        val box=card(root,"Estúdio DSP","Os controles abaixo alteram a música tocando em tempo real.")
        add(box,txt("Preset: ${PresetCatalog.byId(dsp.preset).name}",13f,purple,true))
        val mode=horizontal()
        val bypass=CheckBox(this).apply {text="Bypass (original)";setTextColor(Color.WHITE);isChecked=dsp.bypass
            setOnCheckedChangeListener {_,b->dsp.bypass=b;saveControls()} }
        val mono=CheckBox(this).apply {text="Mono";setTextColor(Color.WHITE);isChecked=dsp.mono
            setOnCheckedChangeListener {_,b->dsp.mono=b;saveControls()} }
        mode.addView(bypass,LinearLayout.LayoutParams(0,-2,1f));mode.addView(mono,LinearLayout.LayoutParams(0,-2,1f));add(box,mode)
        slider(box,"Intensidade do ambiente",dsp.intensity){dsp.intensity=it}
        slider(box,"Graves",dsp.bass){dsp.bass=it}
        slider(box,"Reverberação / eco",dsp.wet){dsp.wet=it}
        slider(box,"Volume seguro",dsp.output){dsp.output=it}
        slider(box,"Brilho",dsp.tone){dsp.tone=it}
        slider(box,"Largura estéreo",dsp.stereo){dsp.stereo=it}
        slider(box,"Movimento panorâmico",dsp.movement){dsp.movement=it}
        slider(box,"Saturação",dsp.distortion){dsp.distortion=it}
        slider(box,"Porta fechada ↔ aberta",1f-dsp.door){dsp.door=1f-it}
        slider(box,"Distância da música",dsp.distance){dsp.distance=it}
        slider(box,"EQ graves",dsp.eqLow){dsp.eqLow=it}
        slider(box,"EQ médios",dsp.eqMid){dsp.eqMid=it}
        slider(box,"EQ agudos",dsp.eqHigh){dsp.eqHigh=it}
        rowButtons(box,"Salvar meus ajustes" to {askSnapshotName()},"Restaurar padrão" to {resetControls();drawPage()})
        val snapshots=card(root,"Meus perfis de estúdio","Salvos no dispositivo; escolha um perfil para restaurar todos os controles.")
        val list=readSnapshots()
        if(list.length()==0)add(snapshots,txt("Você ainda não salvou perfis.",12f,muted))
        for(i in 0 until list.length()) {
            val obj=list.optJSONObject(i)?:continue
            val index=i;rowButtons(snapshots,("♪ "+obj.optString("name","Preset")) to {
                restoreControlJson(obj.optJSONObject("controls")?:JSONObject());drawPage()
            },"Excluir" to {
                val next=JSONArray();for(j in 0 until list.length())if(j!=index)next.put(list.getJSONObject(j))
                prefs.edit().putString("snapshots",next.toString()).apply();drawPage()
            })
        }
    }
    private fun musicLibrary(root:LinearLayout) {
        val box=card(root,"Sua biblioteca local","Importe músicas do armazenamento; as permissões de leitura são mantidas pelo Android quando permitido.")
        rowButtons(box,"+ Adicionar arquivos" to {pickMusic()},"★ Só favoritas" to {favoritesOnly=!favoritesOnly;drawPage()})
        val query=field("Pesquisar música",librarySearch).apply {inputType=InputType.TYPE_CLASS_TEXT}
        add(box,query,bottom=8)
        val listing=vertical();add(box,listing)
        fun rebuild() {
            listing.removeAllViews()
            val filtered=library.items.filter {
                (!favoritesOnly || it.favorite) && (it.title.contains(librarySearch,true) || it.artist.contains(librarySearch,true))
            }
            add(listing,txt("${filtered.size} de ${library.items.size} arquivos",12f,muted))
            filtered.forEach { item ->
                val title="${if(item.favorite)"★ " else ""}${item.title}"
                add(listing,txt(title,14f,Color.WHITE,true))
                add(listing,txt("${item.artist.ifBlank { "Áudio local" }} · ${formatDuration(item.duration)} · ${item.plays} reproduções",11f,muted))
                rowButtons(listing,"▶ Tocar" to {selectedMusic=item.uri;play(item)},"☆" to {
                    item.favorite=!item.favorite;library.save();rebuild()
                },"↓" to {library.move(item,1);rebuild()})
                rowButtons(listing,"↑" to {library.move(item,-1);rebuild()},"Exportar FX" to {
                    selectedMusic=item.uri;askExport()
                },"Excluir da lista" to {library.remove(item);rebuild()})
                val line=View(this).apply {setBackgroundColor(surfaceLight)}
                add(listing,line,1,10)
            }
        }
        query.addTextChangedListener(object:TextWatcher {
            override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){}
            override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){librarySearch=s.toString();rebuild()}
            override fun afterTextChanged(s:Editable?){}
        })
        rebuild()
        val tools=card(root,"Ferramentas de criação","Grave sua voz ou outro som que você tem permissão para registrar; depois aplique os efeitos.")
        add(tools,btn(if(recorder.running)"■ Finalizar gravação" else "● Gravar microfone") {
            if(recorder.running) { val f=recorder.stop();if(f!=null){library.add(Uri.fromFile(f));toast("Gravação adicionada à biblioteca")};drawPage() }
            else if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),REQUEST_MIC)
            else if(recorder.start()){toast("Gravando... toque de novo para parar");drawPage()}
            else toast("Não foi possível iniciar o microfone")
        })
    }
    private fun account(root:LinearLayout) {
        val info=card(root,"Conta local e privacidade","Sem Firebase, serviços externos ou recuperação por e-mail.")
        add(info,txt("Conectado como ${auth.email}",14f,purple,true))
        rowButtons(info,"Alterar senha" to {changePasswordDialog()},"Bloquear agora" to {player.stop();showLogin()})
        val backups=card(root,"Backup e restauração","Exporta ajustes, biblioteca de links locais e perfis; NÃO inclui senha nem arquivos musicais.")
        rowButtons(backups,"Exportar backup" to {createBackup()},"Importar backup" to {restoreBackup()})
        add(backups,txt("Após reinstalação, os links para músicas podem exigir que você selecione os arquivos novamente.",12f,muted))
        val permission=card(root,"Permissões e diagnóstico","O processamento de áudio de outros aplicativos só funciona se eles autorizarem captura.")
        add(permission,txt("Android ${Build.VERSION.RELEASE} · API ${Build.VERSION.SDK_INT}",13f,muted))
        add(permission,txt("Presets DSP disponíveis: ${PresetCatalog.all.size}",13f,muted))
        add(permission,txt("Arquivos na biblioteca: ${library.items.size}",13f,muted))
        add(permission,txt(if(CaptureService.active) "Captura: ativa" else "Captura: inativa",13f,muted))
        add(permission,txt("Dados de áudio ficam no aparelho; abrir links externos usa outros aplicativos.",12f,muted))
        val extra=card(root,"Atalhos externos opcionais","Estes serviços não fazem parte do motor de áudio do ClubFa.")
        rowButtons(extra,"Abrir YouTube" to {openExternal("https://m.youtube.com")},"Abrir Spotify" to {openExternal("https://open.spotify.com")})
        add(extra,txt("Não é possível aplicar efeitos em vídeos incorporados nem contornar bloqueios de captura impostos por outros aplicativos.",12f,muted))
    }
    private fun toast(message:String) {Toast.makeText(this,message,Toast.LENGTH_LONG).show()}
    private fun formatDuration(ms:Long):String {val s=ms/1000;return "%d:%02d".format(s/60,s%60)}
    private fun pickMusic() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE)
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        startActivityForResult(i,REQUEST_PICK)
    }
    private fun playSelected() {
        val item=library.items.firstOrNull { it.uri==selectedMusic } ?: library.items.firstOrNull()
        if(item==null){toast("Adicione uma música primeiro");pickMusic()}else play(item)
    }
    private fun play(item:AudioItem) {
        selectedMusic=item.uri;item.plays++;library.save()
        player.play(Uri.parse(item.uri),item.title) {if(unlocked && activePage=="Início")drawPage()}
        if(activePage=="Início")drawPage()
    }
    private fun playNext() {
        val i=library.items.indexOfFirst { it.uri==selectedMusic }
        if(library.items.isNotEmpty())play(library.items[(i+1).coerceAtLeast(0)%library.items.size])
        else toast("Biblioteca vazia")
    }
    private fun askExport() {
        val uri=selectedMusic ?: library.items.firstOrNull()?.uri
        if(uri==null){toast("Selecione uma música na biblioteca");return}
        exportUri=Uri.parse(uri)
        val name="ClubFa_${System.currentTimeMillis()}.wav"
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).setType("audio/wav").addCategory(Intent.CATEGORY_OPENABLE)
            .putExtra(Intent.EXTRA_TITLE,name)
        startActivityForResult(i,REQUEST_EXPORT)
    }
    private fun startCapture() {
        if(CaptureService.active){toast("Captura já ativa");return}
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO),REQUEST_CAPTURE_PERMISSION)
        else askCapture()
    }
    private fun askCapture() {
        val mgr=getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mgr.createScreenCaptureIntent(),REQUEST_CAPTURE)
    }
    private fun stopCapture() {
        startService(Intent(this,CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        handler.postDelayed({if(unlocked && activePage=="Início")drawPage()},500)
    }
    private fun openExternal(url:String) {
        try {startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url)))}
        catch (_:Exception){toast("Nenhum aplicativo disponível para abrir o link")}
    }
    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(grantResults.firstOrNull()!=PackageManager.PERMISSION_GRANTED){toast("Permissão não concedida");return}
        when(requestCode) {
            REQUEST_CAPTURE_PERMISSION->askCapture()
            REQUEST_MIC-> {if(recorder.start()){toast("Gravação iniciada");drawPage()}else toast("Falha no microfone")}
        }
    }
    @Deprecated("Deprecated Android activity result API")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(resultCode!=RESULT_OK||data==null)return
        when(requestCode) {
            REQUEST_PICK -> {
                val uris=mutableListOf<Uri>()
                data.clipData?.let {clip->for(i in 0 until clip.itemCount)uris.add(clip.getItemAt(i).uri)}
                data.data?.let {if(!uris.contains(it))uris.add(it)}
                uris.forEach { uri ->
                    try {contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}catch (_:Exception){}
                    library.add(uri)
                }
                toast("${uris.size} arquivo(s) adicionado(s)");activePage="Biblioteca";drawPage()
            }
            REQUEST_CAPTURE -> {
                val i=Intent(this,CaptureService::class.java).setAction(CaptureService.ACTION_START)
                    .putExtra(CaptureService.EXTRA_RESULT,resultCode).putExtra(CaptureService.EXTRA_DATA,data)
                startForegroundService(i)
                toast("Captura solicitada; depende da permissão dos apps de origem")
                handler.postDelayed({if(unlocked && activePage=="Início")drawPage()},1200)
            }
            REQUEST_EXPORT -> {
                val from=exportUri;val to=data.data
                if(from!=null&&to!=null){toast("Processando exportação WAV...");player.export(from,to){ok,msg->toast(msg)}}
            }
            REQUEST_BACKUP->data.data?.let {saveBackup(it)}
            REQUEST_RESTORE->data.data?.let {loadBackup(it)}
        }
    }
    private fun resetControls() {
        dsp.intensity=.75f;dsp.bass=.4f;dsp.wet=.42f;dsp.output=.6f
        dsp.tone=.5f;dsp.stereo=.55f;dsp.movement=.25f;dsp.distortion=.04f
        dsp.door=.55f;dsp.distance=.3f;dsp.eqLow=.5f;dsp.eqMid=.5f;dsp.eqHigh=.5f
        dsp.bypass=false;dsp.mono=false;saveControls()
    }
    private fun currentControlJson():JSONObject=JSONObject().apply {
        put("preset",dsp.preset)
        settings.forEach {name->put(name,getSetting(name))}
        put("bypass",dsp.bypass);put("mono",dsp.mono)
    }
    private fun getSetting(k:String):Float=when(k) {
        "intensity"->dsp.intensity;"bass"->dsp.bass;"wet"->dsp.wet;"output"->dsp.output
        "tone"->dsp.tone;"stereo"->dsp.stereo;"movement"->dsp.movement;"distortion"->dsp.distortion
        "door"->dsp.door;"distance"->dsp.distance;"eqLow"->dsp.eqLow;"eqMid"->dsp.eqMid;"eqHigh"->dsp.eqHigh
        else->.5f
    }
    private fun setSetting(k:String,v:Float) {
        val t=v.coerceIn(0f,1f)
        when(k) {
            "intensity"->dsp.intensity=t;"bass"->dsp.bass=t;"wet"->dsp.wet=t;"output"->dsp.output=t
            "tone"->dsp.tone=t;"stereo"->dsp.stereo=t;"movement"->dsp.movement=t;"distortion"->dsp.distortion=t
            "door"->dsp.door=t;"distance"->dsp.distance=t;"eqLow"->dsp.eqLow=t;"eqMid"->dsp.eqMid=t;"eqHigh"->dsp.eqHigh=t
        }
    }
    private fun restoreControlJson(j:JSONObject) {
        dsp.preset=j.optInt("preset",dsp.preset).coerceIn(0,519)
        settings.forEach { k->setSetting(k,j.optDouble(k,getSetting(k).toDouble()).toFloat()) }
        dsp.bypass=j.optBoolean("bypass",false);dsp.mono=j.optBoolean("mono",false);saveControls()
    }
    private fun saveControls() {prefs.edit().putString("settings_json",currentControlJson().toString()).apply()}
    private fun loadControls() {
        try {restoreControlJson(JSONObject(prefs.getString("settings_json","{}")))} catch (_:Exception) {resetControls()}
    }
    private fun readSnapshots():JSONArray=try {JSONArray(prefs.getString("snapshots","[]"))}catch (_:Exception){JSONArray()}
    private fun askSnapshotName() {
        val input=field("Nome do seu perfil").apply{inputType=InputType.TYPE_CLASS_TEXT}
        AlertDialog.Builder(this).setTitle("Salvar perfil local").setView(input)
            .setPositiveButton("Salvar") {_,_->
                val n=input.text.toString().trim().take(60)
                if(n.isNotBlank()) {
                    val list=readSnapshots();list.put(JSONObject().put("name",n).put("controls",currentControlJson()))
                    prefs.edit().putString("snapshots",list.toString()).apply();drawPage()
                }
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun changePasswordDialog() {
        val box=vertical(12)
        val old=field("Senha atual",password=true);val next=field("Nova senha (10+)",password=true)
        add(box,old,bottom=8);add(box,next)
        AlertDialog.Builder(this).setTitle("Alterar senha local").setView(box)
            .setPositiveButton("Alterar") {_,_->
                toast(if(auth.changePassword(old.text.toString(),next.text.toString()))"Senha alterada" else "Não foi possível alterar a senha")
            }.setNegativeButton("Cancelar",null).show()
    }
    private fun createBackup() {
        val i=Intent(Intent.ACTION_CREATE_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE)
            .putExtra(Intent.EXTRA_TITLE,"ClubFa_backup.json")
        startActivityForResult(i,REQUEST_BACKUP)
    }
    private fun restoreBackup() {
        val i=Intent(Intent.ACTION_OPEN_DOCUMENT).setType("application/json").addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(i,REQUEST_RESTORE)
    }
    private fun saveBackup(uri:Uri) {
        try {
            val root=JSONObject().put("format","clubfa-local-v1")
                .put("settings",currentControlJson()).put("songs",library.asJson())
                .put("presets",JSONArray((prefs.getStringSet("preset_favorites",emptySet())?:emptySet()).toList()))
                .put("snapshots",readSnapshots())
            contentResolver.openOutputStream(uri)?.use { it.write(root.toString(2).toByteArray(Charsets.UTF_8)) }
            toast("Backup salvo")
        } catch (e:Exception) {toast("Falha no backup: ${e.localizedMessage}")}
    }
    private fun loadBackup(uri:Uri) {
        try {
            val json=contentResolver.openInputStream(uri)?.use {it.bufferedReader().readText()} ?: error("Arquivo inacessível")
            require(json.length<5_000_000) {"Backup muito grande"}
            val root=JSONObject(json)
            require(root.optString("format")=="clubfa-local-v1") {"Backup incompatível"}
            AlertDialog.Builder(this).setTitle("Restaurar backup?")
                .setMessage("Isso substituirá os ajustes, perfis e a biblioteca atuais. Sua senha NÃO será alterada.")
                .setPositiveButton("Restaurar") {_,_->
                    restoreControlJson(root.getJSONObject("settings"))
                    library.restore(root.optJSONArray("songs")?:JSONArray())
                    val fav=root.optJSONArray("presets")?:JSONArray()
                    val set=mutableSetOf<String>();for(i in 0 until fav.length())set.add(fav.optString(i))
                    prefs.edit().putStringSet("preset_favorites",set)
                        .putString("snapshots",(root.optJSONArray("snapshots")?:JSONArray()).toString()).apply()
                    toast("Backup restaurado; confira as permissões dos arquivos")
                    drawPage()
                }.setNegativeButton("Cancelar",null).show()
        } catch(e:Exception) {toast("Erro no backup: ${e.localizedMessage}")}
    }
}
