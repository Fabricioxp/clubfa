package com.clubfa.app

import android.content.Context
import java.io.File
import java.io.RandomAccessFile
import kotlin.math.*

/** Short, self-generated demo; no copyright recording or network required. */
object DemoAudio {
    fun create(context:Context):File {
        val target=File(context.filesDir,"ClubFa_Demonstracao.wav")
        if(target.exists() && target.length()>100_000L) return target
        val sampleRate=44100;val frames=sampleRate*12
        RandomAccessFile(target,"rw").use { raf ->
            raf.setLength(0);raf.write(ByteArray(44))
            val block=ByteArray(8192)
            var done=0
            while(done<frames) {
                val count=minOf(block.size/4,frames-done)
                for(i in 0 until count) {
                    val t=(done+i).toDouble()/sampleRate
                    val kickEnv=exp(-((t%0.52)*21.0))
                    val kick=sin(2*PI*(60*t+14*(t%0.52)*(t%0.52)))*kickEnv*.35
                    val synth=(sin(2*PI*220*t)*.14+sin(2*PI*330*t)*.08+sin(2*PI*440*t)*.04)
                    val pulse=(kick+synth*(.72+.28*sin(2*PI*1.93*t))).coerceIn(-.65,.65)
                    val l=(pulse*32767).toInt()
                    val r=((pulse*.85+sin(2*PI*554*t)*.03)*32767).toInt()
                    val k=i*4
                    block[k]=l.toByte();block[k+1]=(l ushr 8).toByte()
                    block[k+2]=r.toByte();block[k+3]=(r ushr 8).toByte()
                }
                raf.write(block,0,count*4);done+=count
            }
            LocalAudioEngine.writeWavHeader(raf,sampleRate,2,frames*4L)
        }
        return target
    }
}
