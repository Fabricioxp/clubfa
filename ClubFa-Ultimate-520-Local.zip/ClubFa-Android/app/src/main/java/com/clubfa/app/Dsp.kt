package com.clubfa.app

import kotlin.math.*

/** Stereo streaming PCM16 DSP. All controls are live, buffers allocated only once. */
class Dsp(private val sampleRate: Int = 48000) {
    @Volatile var preset = 0
    @Volatile var intensity = .75f
    @Volatile var bass = .40f
    @Volatile var wet = .42f
    @Volatile var output = .60f
    @Volatile var tone = .50f
    @Volatile var stereo = .55f
    @Volatile var movement = .25f
    @Volatile var distortion = .04f
    @Volatile var door = .55f
    @Volatile var distance = .30f
    @Volatile var eqLow = .50f
    @Volatile var eqMid = .50f
    @Volatile var eqHigh = .50f
    @Volatile var bypass = false
    @Volatile var mono = false
    @Volatile var peak = 0f
    private val delayL = FloatArray(sampleRate * 2)
    private val delayR = FloatArray(sampleRate * 2)
    private var pos = 0
    private var phase = 0.0
    private var lpL = 0f; private var lpR = 0f
    private var hpL = 0f; private var hpR = 0f
    private var loL = 0f; private var loR = 0f
    private var midL = 0f; private var midR = 0f
    private var smoothL = 0f; private var smoothR = 0f
    private var lastPreset = -1

    fun copyControlsFrom(src: Dsp) {
        preset=src.preset; intensity=src.intensity; bass=src.bass; wet=src.wet
        output=src.output; tone=src.tone; stereo=src.stereo; movement=src.movement
        distortion=src.distortion; door=src.door; distance=src.distance
        eqLow=src.eqLow; eqMid=src.eqMid; eqHigh=src.eqHigh
        bypass=src.bypass; mono=src.mono
    }
    fun reset() {
        delayL.fill(0f); delayR.fill(0f)
        pos=0; phase=0.0; lpL=0f; lpR=0f; hpL=0f; hpR=0f
        loL=0f; loR=0f; midL=0f; midR=0f; smoothL=0f; smoothR=0f; peak=0f
    }
    fun process(pcm: ShortArray, n: Int) {
        val p=PresetCatalog.byId(preset)
        if(p.id != lastPreset) { reset(); lastPreset=p.id }
        val amt=intensity.coerceIn(0f,1f)
        val low=bass.coerceIn(0f,1f)
        val mix=(wet * amt).coerceIn(0f,.95f)
        val volume=output.coerceIn(0f,1f)
        val width=(p.width*stereo*1.9f).coerceIn(0f,2.2f)
        val dist=distance.coerceIn(0f,1f)
        val closed=door.coerceIn(0f,1f)
        val darken=(1f-.73f*closed)*(1f-.54f*dist)*(0.50f+tone.coerceIn(0f,1f))
        val cutoff=(p.cutoff*darken).coerceIn(140f, 16500f)
        val lpCoeff=(1.0-exp(-2.0*PI*cutoff/sampleRate)).toFloat()
        val lowCoeff=(1.0-exp(-2.0*PI*145/sampleRate)).toFloat()
        val midCoeff=(1.0-exp(-2.0*PI*1550/sampleRate)).toFloat()
        val highCoeff=(1.0-exp(-2.0*PI*p.highpass/sampleRate)).toFloat()
        val delayFrames=(sampleRate*p.echoMs/1000).coerceIn(1,delayL.size-1)
        val fb=(p.feedback*(.55f+.45f*amt)).coerceIn(0f,.62f)
        val room=(p.room*.48f+.17f).coerceIn(.05f,.74f)
        val lowEq=(eqLow-.5f)*1.6f; val midEq=(eqMid-.5f)*1.4f; val highEq=(eqHigh-.5f)*1.2f
        val bassGain=(p.bass*.5f+low*.7f)*amt
        val drive=(distortion*.85f+p.distortion*.45f)*amt
        val rate=(p.modHz*(.3f+movement*1.7f)).coerceIn(0f,3f)
        val rotation=(p.movement*.5f+movement*.25f).coerceIn(0f,.85f)
        val bypassNow=bypass
        val monoNow=mono
        val sourceGain=1f-dist*.28f
        var maxPeak=0f
        var i=0
        while(i+1<n) {
            val inL=pcm[i]/32768f; val inR=pcm[i+1]/32768f
            if(bypassNow) {
                pcm[i]=(inL*volume*32767).toInt().coerceIn(-32768,32767).toShort()
                pcm[i+1]=(inR*volume*32767).toInt().coerceIn(-32768,32767).toShort()
                maxPeak=max(maxPeak,max(abs(inL*volume),abs(inR*volume)))
                i+=2; continue
            }
            lpL += lpCoeff*(inL-lpL); lpR += lpCoeff*(inR-lpR)
            hpL += highCoeff*(inL-hpL); hpR += highCoeff*(inR-hpR)
            loL += lowCoeff*(inL-loL); loR += lowCoeff*(inR-loR)
            midL += midCoeff*(inL-midL); midR += midCoeff*(inR-midR)
            val cleanL=inL+(lpL-inL)*amt*.93f - hpL*(p.highpass/1700f).coerceIn(0f,.24f)
            val cleanR=inR+(lpR-inR)*amt*.93f - hpR*(p.highpass/1700f).coerceIn(0f,.24f)
            var xL=(cleanL*(1f+highEq)+loL*(bassGain+lowEq)+(midL-loL)*midEq)*sourceGain
            var xR=(cleanR*(1f+highEq)+loR*(bassGain+lowEq)+(midR-loR)*midEq)*sourceGain
            if(drive>.001f) { xL=(tanh((xL*(1+drive*2.2f)).toDouble())/(1+drive*.4f)).toFloat(); xR=(tanh((xR*(1+drive*2.2f)).toDouble())/(1+drive*.4f)).toFloat() }
            val tap=(pos-delayFrames+delayL.size)%delayL.size
            val tap2=(pos-delayFrames/2+delayL.size)%delayL.size
            val echoL=delayL[tap]*.82f+delayR[tap2]*.18f*room
            val echoR=delayR[tap]*.82f+delayL[tap2]*.18f*room
            delayL[pos]=(xL + echoR*fb).coerceIn(-1.3f,1.3f)
            delayR[pos]=(xR + echoL*fb).coerceIn(-1.3f,1.3f)
            pos=(pos+1)%delayL.size
            xL=xL*(1f-mix*.36f)+echoL*mix*room
            xR=xR*(1f-mix*.36f)+echoR*mix*room
            if(rate>0f) {
                phase+=rate*2*PI/sampleRate
                if(phase>2*PI) phase-=2*PI
                val pan=(sin(phase)*rotation).toFloat()
                xL*=1f-pan*.55f; xR*=1f+pan*.55f
            }
            val center=(xL+xR)*.5f
            xL=center+(xL-center)*width; xR=center+(xR-center)*width
            if(monoNow) { val m=(xL+xR)*.5f; xL=m; xR=m }
            // 1-pole smoothing + tanh saturation to bound output; not a mastering limiter.
            smoothL+=.52f*(xL-smoothL); smoothR+=.52f*(xR-smoothR)
            val yL=tanh((smoothL*volume*1.15f).toDouble()).toFloat()
            val yR=tanh((smoothR*volume*1.15f).toDouble()).toFloat()
            pcm[i]=(yL*32767).toInt().coerceIn(-32768,32767).toShort()
            pcm[i+1]=(yR*32767).toInt().coerceIn(-32768,32767).toShort()
            maxPeak=max(maxPeak,max(abs(yL),abs(yR)))
            i+=2
        }
        peak=peak*.72f+maxPeak*.28f
    }
}
