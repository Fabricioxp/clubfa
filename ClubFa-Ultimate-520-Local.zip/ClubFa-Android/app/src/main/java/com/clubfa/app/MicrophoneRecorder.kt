package com.clubfa.app

import android.content.Context
import android.media.*
import java.io.File
import java.io.RandomAccessFile
import kotlin.concurrent.thread

class MicrophoneRecorder(private val context: Context) {
    @Volatile var running=false
        private set
    private var worker:Thread?=null
    private var mic:AudioRecord?=null
    private var outfile:File?=null
    private val rate=44100
    fun start():Boolean {
        if(running) return false
        val min=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        if(min<=0) return false
        return try {
            val record=AudioRecord(MediaRecorder.AudioSource.MIC,rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,maxOf(min*2,8192))
            check(record.state==AudioRecord.STATE_INITIALIZED)
            val directory=File(context.filesDir,"Gravacoes").apply { mkdirs() }
            val output=File(directory,"ClubFa_${System.currentTimeMillis()}.wav")
            outfile=output;mic=record
            running=true
            record.startRecording()
            worker=thread(name="ClubFa-Recorder") {
                try {
                    RandomAccessFile(output,"rw").use { raf ->
                        raf.write(ByteArray(44))
                        val buffer=ShortArray(4096)
                        var written=0L
                        while(running) {
                            val n=record.read(buffer,0,buffer.size,AudioRecord.READ_BLOCKING)
                            if(n>0) {
                                val bytes=ByteArray(n*2)
                                for(i in 0 until n) { val v=buffer[i].toInt();bytes[2*i]=v.toByte();bytes[2*i+1]=(v ushr 8).toByte() }
                                raf.write(bytes);written+=bytes.size
                            } else if(n<0) break
                        }
                        LocalAudioEngine.writeWavHeader(raf,rate,1,written)
                    }
                } finally {try {record.release()}catch(_:Exception){} }
            }
            true
        } catch (_:Exception) { running=false;mic?.release();mic=null;false }
    }
    fun stop():File? {
        if(!running) return null
        running=false
        try {mic?.stop()} catch (_:Exception) {}
        try {worker?.join(1700)} catch (_:Exception) {}
        return outfile?.takeIf { it.isFile && it.length()>44 }
    }
}
