package com.clubfa.app

import android.app.*
import android.content.*
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "clubfa.START"
        const val ACTION_STOP = "clubfa.STOP"
        const val ACTION_SETTINGS = "clubfa.SETTINGS"
        const val EXTRA_RESULT = "clubfa.RESULT"
        const val EXTRA_DATA = "clubfa.DATA"
        @Volatile var active = false
        @Volatile var status = "Inativo"
        val dsp = Dsp()
    }
    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var worker: Thread? = null
    @Volatile private var running = false
    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() { stopSelf() }
    }
    override fun onBind(intent: Intent?) : IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_SETTINGS -> return START_NOT_STICKY
            ACTION_START -> {
                if (running) return START_NOT_STICKY
                makeNotification()
                try {
                    val result = intent.getIntExtra(EXTRA_RESULT, Activity.RESULT_CANCELED)
                    @Suppress("DEPRECATION")
                    val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                               else intent.getParcelableExtra<Intent>(EXTRA_DATA)
                    if (result != Activity.RESULT_OK || data == null) throw IllegalArgumentException("Autorização não concedida")
                    val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = mgr.getMediaProjection(result, data)
                    projection!!.registerCallback(projectionCallback, Handler(Looper.getMainLooper()))
                    startAudio(projection!!)
                } catch (e: Exception) {
                    status = "Falha ao iniciar: ${e.localizedMessage}"
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }
    private fun makeNotification() {
        val channel = NotificationChannel("clubfa_capture", "ClubFa - áudio", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        val stopIntent = Intent(this, CaptureService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 0, stopIntent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val notification = Notification.Builder(this, "clubfa_capture")
            .setContentTitle("ClubFa • efeitos ligados")
            .setContentText("Capturando apenas áudio permitido pelo Android")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(null, "Parar", pending).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(8, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(8, notification)
    }
    private fun startAudio(p: MediaProjection) {
        val sampleRate = 48000
        val channels = AudioFormat.CHANNEL_IN_STEREO
        val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate).setChannelMask(channels).build()
        val config = AudioPlaybackCaptureConfiguration.Builder(p)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .excludeUid(applicationInfo.uid) // Avoid capturing own processed output.
            .build()
        val minIn = AudioRecord.getMinBufferSize(sampleRate, channels, AudioFormat.ENCODING_PCM_16BIT)
        val minOut = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        record = AudioRecord.Builder().setAudioFormat(format)
            .setBufferSizeInBytes(maxOf(minIn * 2, 16384))
            .setAudioPlaybackCaptureConfig(config).build()
        val outFmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
        val attrs = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_NONE).build()
        track = AudioTrack.Builder().setAudioAttributes(attrs).setAudioFormat(outFmt)
            .setBufferSizeInBytes(maxOf(minOut * 2, 16384)).setTransferMode(AudioTrack.MODE_STREAM).build()
        check(record!!.state == AudioRecord.STATE_INITIALIZED && track!!.state == AudioTrack.STATE_INITIALIZED) { "Dispositivo de áudio indisponível" }
        running = true; active = true; status = "Captura ligada (somente apps compatíveis)"
        record!!.startRecording(); track!!.play()
        worker = Thread {
            val buf = ShortArray(2048) // multiple of stereo frames
            try {
                while (running) {
                    val n = record?.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING) ?: break
                    if (n > 0) { dsp.process(buf, n); track?.write(buf, 0, n, AudioTrack.WRITE_BLOCKING) }
                    else if (n < 0) break
                }
            } catch (_: Exception) { status = "A captura foi interrompida" }
        }.also { it.name = "ClubFa-Audio"; it.start() }
    }
    override fun onDestroy() {
        running = false; active = false
        try { record?.stop() } catch (_: Exception) {}
        try { track?.pause(); track?.flush() } catch (_: Exception) {}
        try { worker?.join(500) } catch (_: Exception) {}
        record?.release(); record=null
        track?.release(); track=null
        try { projection?.unregisterCallback(projectionCallback); projection?.stop() } catch (_: Exception) {}
        projection=null
        status = "Inativo"
        super.onDestroy()
    }
}
