package com.clubfa.app

import android.content.Context
import android.media.*
import android.net.Uri
import java.nio.ByteOrder
import java.nio.ByteBuffer

/** Uses built-in Android decoders. Supports audio formats available on the current device. */
object PcmDecoder {
    fun decode(context: Context, uri: Uri, alive: () -> Boolean,
               onFormat:(sampleRate:Int)->Unit, onPcm:(pcm:ShortArray, n:Int)->Unit) {
        val extractor=MediaExtractor()
        var decoder:MediaCodec?=null
        try {
            extractor.setDataSource(context,uri,null)
            var audioTrack=-1
            for(i in 0 until extractor.trackCount) {
                val f=extractor.getTrackFormat(i)
                if((f.getString(MediaFormat.KEY_MIME)?:"").startsWith("audio/")) { audioTrack=i; break }
            }
            require(audioTrack>=0) { "Não há faixa de áudio neste arquivo" }
            extractor.selectTrack(audioTrack)
            val format=extractor.getTrackFormat(audioTrack)
            val mime=format.getString(MediaFormat.KEY_MIME)?:error("Formato desconhecido")
            if(mime.equals("audio/raw",ignoreCase=true)) {
                val rate=format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                val channels=format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                require(channels in 1..2) { "WAV com mais de dois canais não é compatível" }
                val encoding=if(format.containsKey(MediaFormat.KEY_PCM_ENCODING)) format.getInteger(MediaFormat.KEY_PCM_ENCODING) else AudioFormat.ENCODING_PCM_16BIT
                require(encoding==AudioFormat.ENCODING_PCM_16BIT) { "WAV PCM precisa ser de 16 bits" }
                onFormat(rate)
                val raw=ByteBuffer.allocateDirect(32768)
                while(alive()) {
                    raw.clear()
                    val count=extractor.readSampleData(raw,0)
                    if(count<=0)break
                    raw.position(0);raw.limit(count);raw.order(ByteOrder.LITTLE_ENDIAN)
                    val frames=count/2/channels
                    val pcm=ShortArray(frames*2)
                    for(j in 0 until frames) {
                        val l=raw.short;val r=if(channels==2)raw.short else l
                        pcm[j*2]=l;pcm[j*2+1]=r
                    }
                    onPcm(pcm,pcm.size)
                    extractor.advance()
                }
                return
            }
            decoder=MediaCodec.createDecoderByType(mime)
            decoder.configure(format,null,null,0);decoder.start()
            val info=MediaCodec.BufferInfo()
            var eosIn=false;var eosOut=false
            var rate=format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels=format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var pcmEncoding=AudioFormat.ENCODING_PCM_16BIT
            var notified=false
            while(alive() && !eosOut) {
                if(!eosIn) {
                    val index=decoder.dequeueInputBuffer(10_000)
                    if(index>=0) {
                        val input=decoder.getInputBuffer(index)?:error("Input buffer não disponível")
                        val count=extractor.readSampleData(input,0)
                        if(count<0) { decoder.queueInputBuffer(index,0,0,0L,MediaCodec.BUFFER_FLAG_END_OF_STREAM);eosIn=true }
                        else { decoder.queueInputBuffer(index,0,count,extractor.sampleTime,0);extractor.advance() }
                    }
                }
                val index=decoder.dequeueOutputBuffer(info,10_000)
                when(index) {
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f=decoder.outputFormat
                        rate=f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels=f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        pcmEncoding=if(f.containsKey(MediaFormat.KEY_PCM_ENCODING)) f.getInteger(MediaFormat.KEY_PCM_ENCODING) else AudioFormat.ENCODING_PCM_16BIT
                        require(channels in 1..2) { "O ClubFa aceita áudio mono ou estéreo" }
                        require(pcmEncoding==AudioFormat.ENCODING_PCM_16BIT || pcmEncoding==AudioFormat.ENCODING_PCM_FLOAT) { "Formato PCM não suportado" }
                        if(!notified) {onFormat(rate);notified=true}
                    }
                    in 0..Int.MAX_VALUE -> {
                        if(!notified) {onFormat(rate);notified=true}
                        if(info.size>0) {
                            val buf=decoder.getOutputBuffer(index)?:error("Output buffer não disponível")
                            buf.position(info.offset);buf.limit(info.offset+info.size)
                            val copy=buf.slice().order(ByteOrder.LITTLE_ENDIAN)
                            val samples=if(pcmEncoding==AudioFormat.ENCODING_PCM_FLOAT) info.size/4 else info.size/2
                            val frames=samples/channels
                            val pcm=ShortArray(frames*2)
                            for(j in 0 until frames) {
                                fun sample():Short = if(pcmEncoding==AudioFormat.ENCODING_PCM_FLOAT) (copy.float.coerceIn(-1f,1f)*32767f).toInt().toShort() else copy.short
                                val l=sample();val r=if(channels==2)sample() else l
                                pcm[2*j]=l;pcm[2*j+1]=r
                            }
                            onPcm(pcm,pcm.size)
                        }
                        eosOut=(info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM)!=0
                        decoder.releaseOutputBuffer(index,false)
                    }
                }
            }
        } finally {
            try { decoder?.stop() } catch (_:Exception) {}
            try { decoder?.release() } catch (_:Exception) {}
            extractor.release()
        }
    }
}
