package com.clubfa.app

import kotlin.math.*

/** Each preset has an actual, deterministic DSP configuration, not a placeholder UI entry. */
data class SoundPreset(
    val id: Int, val name: String, val category: String,
    val cutoff: Float, val echoMs: Int, val feedback: Float,
    val room: Float, val bass: Float, val width: Float,
    val modHz: Float, val movement: Float, val distortion: Float,
    val highpass: Float
)

object PresetCatalog {
    private val rooms = listOf(
        "Banheiro da balada", "Pista principal", "Atrás da parede", "Do lado de fora",
        "Corredor de acesso", "Área VIP", "Estacionamento", "Rooftop",
        "Galpão industrial", "Túnel", "Catedral", "Cinema vazio",
        "Carro fechado", "Quarto vizinho", "Piscina coberta", "Festival distante",
        "Caverna", "Sala de concerto", "Metrô subterrâneo", "Rádio vintage"
    )
    private val variants = listOf(
        "Natural", "Suave", "Envolvente", "Graves fortes", "Bem distante", "Bem próximo",
        "Porta fechada", "Porta aberta", "Com eco", "Eco longo", "Som abafado", "Som brilhante",
        "Estéreo amplo", "Estéreo estreito", "Movimento lento", "Movimento rápido", "Profundo", "Seco",
        "Reverberante", "Noturno", "Subgrave", "Lo-fi", "Atmosférico", "Intenso"
    )
    val all: List<SoundPreset> = buildList {
        rooms.forEachIndexed { r, room ->
            variants.forEachIndexed { v, variant ->
                val a = (r * 37 + 9) % 17
                val t = (v * 13 + r * 3) % 19
                val cutoff = (450f + r * 285f + t * 130f).coerceIn(340f, 15500f) * when (v) {
                    4,6,10 -> .55f; 7,11 -> 1.45f; else -> 1f
                }
                val echo = (32 + r * 14 + v * 19 + t * 2).coerceIn(18, 1200)
                add(SoundPreset(r * variants.size + v, "$room · $variant", room,
                    cutoff.coerceIn(250f, 17000f), echo,
                    (.09f + (a + v % 6) * .018f).coerceIn(.08f,.55f),
                    (.12f + (r % 6)*.10f + if(v==18 || v==22) .26f else 0f).coerceIn(0f,.92f),
                    (.10f + (r % 5)*.11f + if(v==3 || v==20) .34f else 0f).coerceIn(0f,.95f),
                    (when(v) { 12->1.7f; 13->.16f; else->.6f+(r%6)*.17f }).coerceIn(.15f,1.8f),
                    if (v in 14..15 || v==22) .12f+(v%5)*.18f else 0f,
                    if (v==14 || v==15) .15f+(r%4)*.15f else .015f,
                    if (v==21 || v==23) .17f+(r%4)*.07f else .02f,
                    if (v==21 || r==19) 170f+(v%4)*40f else 15f
                ))
            }
        }
        // A distinct, 40-preset laboratory bank using extreme yet bounded sonic recipes.
        val experiments = listOf(
            "Sonho VHS","Fita cansada","Rádio cósmico","Eco reverso inspirado","Névoa digital",
            "Cabine espacial","Cristal brilhante","Câmara profunda","Pulso subaquático","Ondas giratórias",
            "Memória distante","Fantasma estéreo","Horizonte infinito","Duto metálico","Subgrave orbital",
            "Deserto de ecos","Satélite perdido","Holograma","Vinil antigo","Sombra noturna",
            "Túnel temporal","Gravidade zero","Coração eletrônico","Noite de neon","Outro universo",
            "Robô analógico","Sussurro distante","Chuva sintética","Sala impossível","Panorama infinito",
            "Metrópole líquida","Luz pulsante","Porta dimensional","Sala de espelhos","Frequência fantasma",
            "Nebulosa","Reator distante","Lembrança de verão","Eco elétrico","Fim da festa"
        )
        experiments.forEachIndexed { e, title ->
            add(SoundPreset(480+e, "LAB · $title", "Laboratório", 350f+(e*313)%12000,
                40 + (e*97)%1100, .12f+(e%8)*.046f, .2f+(e%7)*.1f,
                .12f+(e%6)*.12f, .3f+(e%8)*.19f, (e%5)*.25f,
                .08f+(e%6)*.09f, (e%4)*.105f, 30f+(e%8)*42f))
        }
    }
    init { check(all.size==520 && all.map { it.id }.toSet().size==520) }
    fun byId(id: Int) = all[id.coerceIn(0, all.lastIndex)]
    val categories: List<String> = all.map { it.category }.distinct()
}
