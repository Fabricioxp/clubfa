package com.clubfa.app

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Local-only access gate. Does not claim server-backed authentication or protect rooted devices. */
class LocalAuth(context: Context) {
    private val prefs=context.getSharedPreferences("clubfa_identity",Context.MODE_PRIVATE)
    val registered get() = prefs.contains("hash")
    val email get() = prefs.getString("email","") ?: ""
    private fun derive(pw: CharArray, salt: ByteArray): ByteArray {
        val spec=PBEKeySpec(pw,salt,210_000,256)
        return try { SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded }
        finally { spec.clearPassword(); pw.fill('\u0000') }
    }
    fun create(email: String, password: String): Boolean {
        if(registered || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() || password.length<10) return false
        val salt=ByteArray(24).also { SecureRandom().nextBytes(it) }
        val hash=derive(password.toCharArray(),salt)
        return prefs.edit().putString("email",email.trim().lowercase())
            .putString("salt",Base64.encodeToString(salt,Base64.NO_WRAP))
            .putString("hash",Base64.encodeToString(hash,Base64.NO_WRAP)).commit()
    }
    fun verify(email: String, password: String): Boolean {
        if(!registered || email.trim().lowercase()!=this.email) return false
        return try {
            val salt=Base64.decode(prefs.getString("salt",""),Base64.NO_WRAP)
            val expected=Base64.decode(prefs.getString("hash",""),Base64.NO_WRAP)
            MessageDigest.isEqual(expected,derive(password.toCharArray(),salt))
        } catch (_:Exception) { false }
    }
    fun changePassword(old: String, updated: String): Boolean {
        if(updated.length<10 || !verify(email,old)) return false
        val salt=ByteArray(24).also { SecureRandom().nextBytes(it) }
        val hash=derive(updated.toCharArray(),salt)
        return prefs.edit().putString("salt",Base64.encodeToString(salt,Base64.NO_WRAP))
            .putString("hash",Base64.encodeToString(hash,Base64.NO_WRAP)).commit()
    }
}
