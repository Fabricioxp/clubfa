plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.clubfa.app"
    compileSdk = 35
    defaultConfig { applicationId = "com.clubfa.app"; minSdk = 29; targetSdk = 35; versionCode = 6; versionName = "6.0-local-260" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
