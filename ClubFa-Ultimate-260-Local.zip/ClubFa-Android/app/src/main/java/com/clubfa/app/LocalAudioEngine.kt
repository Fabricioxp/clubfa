package com.clubfa.app

import android.content.Context
import android.media.*
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import kotlin.concurrent.thread

class LocalAudioEngine(private val context: Context, private val controls: Dsp, private val listener:(String)->Unit) {
    private val main=Handler(Looper.getMainLooper())
    @Volatile private var session=0
    @Volatile private var paused=false
    @Volatile private var playing=false
    @Volatile private var currentTrack:AudioTrack?=null
    @Volatile var current:String=""
        private set
    @Volatile var lastEndedNaturally=false
        private set
    val isPlaying get()=playing
    val isPaused get()=paused
    private fun inform(s:String) { main.post { listener(s) } }
    fun stop() {
        session++;paused=false;playing=false;current="";lastEndedNaturally=false
        try {currentTrack?.pause()} catch (_:Exception) {}
        inform("Reprodução parada")
    }
    fun pauseOrResume() {
        if(!playing) return
        paused=!paused
        try { if(paused) currentTrack?.pause() else currentTrack?.play() } catch (_:Exception) {}
        inform(if(paused) "Pausado" else "Reproduzindo")
    }
    fun play(uri:Uri, title:String, finished:()->Unit) {
        stop();val mine=++session
        playing=true;current=title; paused=false;inform("Preparando $title")
        thread(name="ClubFa-Player") {
            var out:AudioTrack?=null
            var engine=Dsp()
            try {
                PcmDecoder.decode(context,uri,{ session==mine },{ rate ->
                    engine=Dsp(rate)
                    val safe=rate.coerceIn(8000,192000)
                    val fmt=AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(safe).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
                    val min=AudioTrack.getMinBufferSize(safe,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT)
                    check(min>0) { "Saída de áudio incompatível" }
                    out=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_NONE).build())
                        .setAudioFormat(fmt).setBufferSizeInBytes(maxOf(min*3,32768))
                        .setTransferMode(AudioTrack.MODE_STREAM).build()
                    check(out!!.state==AudioTrack.STATE_INITIALIZED) { "Falha ao criar a saída de áudio" }
                    currentTrack=out
                    out!!.play();inform("▶ $title")
                }, { pcm, size ->
                    while(paused && session==mine) Thread.sleep(80)
                    if(session!=mine) return@decode
                    engine.copyControlsFrom(controls);engine.process(pcm,size)
                    var offset=0
                    while(offset<size && session==mine) {
                        val written=out?.write(pcm,offset,size-offset,AudioTrack.WRITE_BLOCKING) ?: break
                        if(written<=0) break
                        offset+=written
                    }
                    controls.peak=engine.peak
                })
                if(session==mine) {
                    out?.let { track ->
                        try { if(!paused) { val frames=track.playbackHeadPosition; if(frames>=0) Thread.sleep(120) } } catch (_:Exception) {}
                    }
                    lastEndedNaturally=true
                    inform("Fim de $title")
                }
            } catch(e:Exception) { if(session==mine) inform("Erro no player: ${e.localizedMessage?:"arquivo incompatível"}") }
            finally {
                try { out?.pause();out?.flush();out?.release() } catch (_:Exception) {}
                if(currentTrack===out) currentTrack=null
                if(session==mine) {playing=false;paused=false;current="";main.post { finished() }}
            }
        }
    }
    fun export(uri:Uri,destination:Uri,finished:(Boolean,String)->Unit) {
        val safeControls=Dsp().also { it.copyControlsFrom(controls) }
        thread(name="ClubFa-Export") {
            val tmp=File.createTempFile("clubfa_export_",".wav",context.cacheDir)
            var result=false;var message=""
            try {
                RandomAccessFile(tmp,"rw").use { raf ->
                    raf.write(ByteArray(44))
                    var rate=48000
                    var processor=Dsp()
                    var sizeBytes=0L
                    PcmDecoder.decode(context,uri,{true},{ r -> rate=r;processor=Dsp(rate) },{ pcm,n ->
                        processor.copyControlsFrom(safeControls);processor.process(pcm,n)
                        val b=ByteArray(n*2)
                        for(i in 0 until n) { val v=pcm[i].toInt();b[i*2]=v.toByte();b[i*2+1]=(v ushr 8).toByte() }
                        raf.write(b);sizeBytes+=b.size
                        require(sizeBytes<3_800_000_000L) { "Arquivo excede o limite WAV" }
                    })
                    writeWavHeader(raf,rate,2,sizeBytes)
                }
                val stream=context.contentResolver.openOutputStream(destination,"w") ?: error("Não foi possível criar o arquivo")
                stream.use { sink -> tmp.inputStream().use { src -> src.copyTo(sink, 65536) } }
                result=true;message="Arquivo WAV exportado com sucesso"
            } catch(e:Exception) { message="Erro na exportação: ${e.localizedMessage}" }
            finally {tmp.delete();main.post { finished(result,message) }}
        }
    }
    companion object {
        fun writeWavHeader(raf:RandomAccessFile, rate:Int, channels:Int,bytes:Long) {
            fun write32(n:Long) { val x=n.toInt();raf.write(byteArrayOf(x.toByte(),(x ushr 8).toByte(),(x ushr 16).toByte(),(x ushr 24).toByte())) }
            fun write16(n:Int) { raf.write(byteArrayOf(n.toByte(),(n ushr 8).toByte())) }
            raf.seek(0)
            raf.writeBytes("RIFF");write32(bytes+36);raf.writeBytes("WAVE")
            raf.writeBytes("fmt ");write32(16);write16(1);write16(channels)
            write32(rate.toLong());write32(rate.toLong()*channels*2);write16(channels*2);write16(16)
            raf.writeBytes("data");write32(bytes)
        }
    }
}
