package com.clubfa.app

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

data class AudioItem(val uri: String, var title: String, var artist: String = "", val duration: Long = 0L,
                     var favorite: Boolean = false, var plays: Int = 0,
                     var addedAt: Long = 0L, var lastPlayedAt: Long = 0L, var category: String = "Geral")

class LocalLibrary(private val context: Context) {
    private val prefs=context.getSharedPreferences("clubfa_library",Context.MODE_PRIVATE)
    val items=mutableListOf<AudioItem>()
    init {
        try {
            val data=JSONArray(prefs.getString("songs","[]"))
            for(i in 0 until data.length()) {
                val it=data.getJSONObject(i)
                items.add(AudioItem(it.getString("uri"),it.optString("title","Áudio"),
                    it.optString("artist",""),it.optLong("duration",0L),it.optBoolean("favorite"),it.optInt("plays",0),
                    it.optLong("addedAt",0L),it.optLong("lastPlayedAt",0L),it.optString("category","Geral")))
            }
        } catch (_:Exception) { items.clear() }
    }
    fun add(uri: Uri): AudioItem {
        items.find { it.uri==uri.toString() }?.let { return it }
        var title=uri.lastPathSegment ?: "Música"
        var artist=""; var duration=0L
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use { c ->
                if(c.moveToFirst()) title=c.getString(0) ?: title
            }
        } catch (_:Exception) { }
        try {
            val m=MediaMetadataRetriever()
            m.setDataSource(context,uri)
            title=m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() } ?: title
            artist=m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
            duration=m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            m.release()
        } catch (_:Exception) { }
        val item=AudioItem(uri.toString(),title,artist,duration,addedAt=System.currentTimeMillis())
        items.add(item); save(); return item
    }
    fun duplicateUris():Set<String> = items.groupBy { it.title.trim().lowercase() to it.duration }
        .filter { it.key.second>0 && it.value.size>1 }.values.flatten().map { it.uri }.toSet()
    fun rename(item:AudioItem,title:String,artist:String,category:String) {
        // Edits the LOCAL LIBRARY only, never silently modifies the original audio file.
        item.title=title.trim().ifBlank { item.title }
        item.artist=artist.trim(); item.category=category.trim().ifBlank { "Geral" };save()
    }
    fun remove(item:AudioItem) { items.remove(item); save() }
    fun move(item:AudioItem,dir:Int) {
        val i=items.indexOf(item); val target=i+dir
        if(i>=0 && target in items.indices) { items.removeAt(i);items.add(target,item);save() }
    }
    fun save() {
        val a=JSONArray()
        items.forEach { i -> a.put(JSONObject().put("uri",i.uri).put("title",i.title).put("artist",i.artist)
            .put("duration",i.duration).put("favorite",i.favorite).put("plays",i.plays)
            .put("addedAt",i.addedAt).put("lastPlayedAt",i.lastPlayedAt).put("category",i.category)) }
        prefs.edit().putString("songs",a.toString()).apply()
    }
    fun asJson():JSONArray=JSONArray(prefs.getString("songs","[]"))
    fun restore(data:JSONArray) {
        prefs.edit().putString("songs",data.toString()).commit()
        items.clear()
        for(i in 0 until data.length()) {
            try { val v=data.getJSONObject(i); items.add(AudioItem(v.getString("uri"),v.optString("title"),v.optString("artist"),v.optLong("duration"),v.optBoolean("favorite"),v.optInt("plays"),v.optLong("addedAt",0L),
                v.optLong("lastPlayedAt",0L),v.optString("category","Geral"))) }
            catch (_:Exception) {}
        }
    }
}
