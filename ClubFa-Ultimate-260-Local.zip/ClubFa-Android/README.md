# ClubFa Ultimate Local — atualização 260

Aplicativo Android Kotlin sem Firebase e sem permissão de Internet. **O APK completo não foi compilado neste ambiente**; execute o workflow no GitHub para confirmar.

## Implementado neste código

- Redução de 520 para **260 presets DSP**: 20 ambientes × 11 variantes + 40 presets experimentais. Mantém o mesmo motor DSP, incluindo os controles de porta, distância, graves, eco, reverberação, estéreo, EQ de 3 bandas e saturação. A numeração dos presets mudou: favoritos antigos por ID podem apontar para outro efeito e o preset ativo antigo será limitado à nova faixa.
- **Temporizador de desligamento** de 15, 30 ou 60 minutos enquanto o app está aberto.
- **Reprodução automática da próxima faixa** após término natural da atual; não equivale a crossfade ou gapless garantido.
- **Busca na biblioteca** por título, artista ou categoria, filtro por duração mínima, ordenação por título/artista, mais ouvidas, recentes e duração.
- **Contagem de reproduções**, data de inclusão e último play persistidos; classificação de categoria personalizada.
- **Edição dos metadados na biblioteca local** (título, artista e categoria). Não altera tags do arquivo de áudio original.
- **Detecção indicativa de duplicatas** por título e duração; não é comparação de hash de conteúdo.
- Já existentes e mantidos: importação múltipla, favoritos, reordenação por botões, exportação WAV processada, gravação de microfone, snapshots, backup JSON, login local e captura Android apenas quando autorizada.

## Não implementado nesta versão

As demais ideias selecionadas não foram implementadas: letras LRC sincronizadas, arrastar a fila, crossfade, reprodução gapless garantida, marcadores e loop A-B, retomada na posição exata, detecção de corrupção completa, escrita de tags no arquivo, capas, pastas/playlists inteligentes, EQ paramétrico, automações, corte/fade de áudio, múltiplos codecs de exportação, widgets, notificações de mídia, serviço de reprodução em segundo plano, biometria, backup criptografado, FFT/BPM, classificação inteligente, etc. **Não há botões de mentira para esses recursos.**

## Como compilar pelo celular

1. Envie o ZIP `ClubFa-Ultimate-260-Local.zip` para a **raiz** do repositório GitHub (não extraia).
2. Substitua `.github/workflows/build-apk.yml` pelo arquivo `build-apk-260.yml` fornecido separadamente.
3. Abra Actions → **ClubFa Ultimate 260 - Gerar APK** → Run workflow.
4. Se a compilação terminar verde, baixe `ClubFa-Ultimate-260-APK` nos Artifacts.

Os dados de login e biblioteca existentes usam o mesmo identificador de aplicativo, mas faça backup antes de instalar outra versão. Nunca coloque senhas no repositório.
