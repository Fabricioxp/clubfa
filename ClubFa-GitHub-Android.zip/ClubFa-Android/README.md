# ClubFa — App Android nativo (protótipo)

Aplicativo Kotlin (Android 10+, API 29+) com interface roxo/escura, 8 presets, filtros DSP com eco e controle de volume, reprodução de WAV PCM16 local e **tentativa** de captura do áudio de outros apps.

## Como gerar um APK sem pagar

1. Instale o **Android Studio** em um computador (Windows/macOS/Linux).
2. Descompacte este ZIP, escolha **Open** e selecione a pasta `ClubFa-Android`.
3. Aguarde a sincronização do Gradle (exige conexão com a internet na primeira vez).
4. Em **Build > Build Bundle(s) / APK(s) > Build APK(s)**, gere o APK de teste.
5. Instale `app/build/outputs/apk/debug/app-debug.apk` no Android (permita instalações de fontes selecionadas).

Este pacote é **código-fonte**, não um APK compilado. Não houve teste em dispositivo Android real neste ambiente.

## Uso

- Abra o ClubFa, selecione o preset e ajuste intensidade/graves/eco/volume.
- Clique em **Ativar efeitos em outros apps**, autorize a permissão de áudio e a captura do Android.
- Abra um app que **permita** captura (nem todo app permite). O áudio processado sairá pelo dispositivo, mas o original também pode continuar tocando.
- Para testar um efeito mais previsível, use **Abrir arquivo WAV** com PCM 16-bit estéreo em 44,1 ou 48 kHz.

## Limitações importantes

- O **Spotify normalmente pode bloquear a captura**. Este projeto não contorna DRM nem políticas de proteção de áudio.
- Captura de áudio de terceiros no Android tem latência e **não substitui** o áudio que o app de origem envia ao alto-falante. Podem ocorrer som duplo/eco; use volume baixo e fones.
- YouTube: link abre navegador/app oficial. O player do YouTube não fornece áudio bruto para os efeitos nativos.
- WAV local: apenas PCM 16-bit estéreo 44,1/48 kHz; MP3 e outros formatos ainda não estão implementados no player nativo.
- O DSP usa filtro low-pass, reforço moderado de graves, delay com realimentação limitada e soft clipping; não garante áudio sem distorção em todas as combinações.
- Não há coleta, envio nem gravação de áudio em servidor. Uma notificação mostra quando a captura está ativa.

## Referências oficiais

- Android AudioPlaybackCapture: https://developer.android.com/media/platform/av-capture
- MediaProjection: https://developer.android.com/media/grow/media-projection

## Gerar APK pelo GitHub Actions (sem computador)

O arquivo `.github/workflows/build-apk.yml` automatiza a compilacao. Publique **o conteudo desta pasta** na raiz de um repositorio GitHub, preservando as subpastas `app/` e `.github/`.

1. Crie um repositorio no GitHub com o nome `ClubFa-Android`.
2. Envie os arquivos e pastas desta pasta para a raiz do repositorio (nao envie apenas o ZIP, pois o GitHub Actions nao extrai automaticamente um ZIP armazenado no repositorio).
3. Na aba `Actions`, abra `Gerar APK ClubFa` e pressione `Run workflow`.
4. Quando a execucao estiver verde, abra a execucao e baixe o artefato `ClubFa-APK`. Extraia o ZIP de artefato para obter `app-debug.apk`.
5. Instale o APK no Android permitindo a instalacao a partir do navegador/gerenciador de arquivos.

Observacao: projeto sem compilacao validada no aparelho; o Actions mostrara qualquer erro de compilacao. APK de debug nao e distribuicao publica assinada para Play Store.
