package com.clubfa.app

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.*
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.view.*
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 9, 25)
    private val panel = Color.rgb(31, 21, 52)
    private val purple = Color.rgb(169, 122, 255)
    private val muted = Color.rgb(191, 179, 209)
    private val dsp get() = CaptureService.dsp
    private lateinit var stateText: TextView
    private lateinit var start: Button
    private var localThread: Thread? = null
    @Volatile private var localPlay = false
    private val REQUEST_AUDIO = 501
    private val REQUEST_CAPTURE = 502
    private val REQUEST_WAV = 503
    private val names = arrayOf("Original / limpo", "Banheiro da balada", "Do lado de fora", "Pista de dança", "Túnel roxo", "Atrás da parede", "Salão gigante", "Eco infinito")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        drawUi()
    }
    private fun shape(color: Int, rad: Float = 22f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = rad * resources.displayMetrics.density
    }
    private fun text(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false): TextView = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) setTypeface(null, Typeface.BOLD)
        setPadding(dp(4),dp(8),dp(4),dp(8))
    }
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun button(label: String, action: () -> Unit): Button = Button(this).apply {
        text = label; isAllCaps = false; textSize = 14f; setTextColor(Color.WHITE)
        background = shape(purple, 16f)
        setPadding(dp(12),dp(10),dp(12),dp(10))
        setOnClickListener { action() }
    }
    private fun addBlock(parent: LinearLayout, title: String, description: String = ""): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background=shape(panel)
            setPadding(dp(17),dp(13),dp(17),dp(16))
        }
        card.addView(text(title,19f,Color.WHITE,true))
        if (description.isNotBlank()) card.addView(text(description,12.5f,muted))
        parent.addView(card, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(14) })
        return card
    }
    private fun drawUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); fillViewport=true }
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(18),dp(23),dp(18),dp(24)) }
        scroll.addView(root); setContentView(scroll)
        root.addView(text("◈  ClubFa",34f,purple,true))
        root.addView(text("AUDIO LAB  ·  ANDROID",12f,muted,true))
        root.addView(text("Sua música em outro ambiente.",16f,Color.WHITE))

        val capture = addBlock(root,"Capturar áudio de outros apps", "Android 10+ · Só funciona se o aplicativo de origem permitir captura. Spotify e alguns serviços podem bloquear. O áudio original não é silenciado.")
        stateText = text(if(CaptureService.active) "● ${CaptureService.status}" else "○ Captura desligada",13f,muted)
        capture.addView(stateText)
        start = button(if(CaptureService.active) "Parar captura" else "Ativar efeitos em outros apps") { if(CaptureService.active) stopCapture() else requestCapture() }
        capture.addView(start,LinearLayout.LayoutParams(-1,dp(52)))
        capture.addView(text("Dica: teste com fones de ouvido e volume baixo. O áudio direto do app pode se misturar ao processado, causando eco e atraso.",12f,muted))

        val presets = addBlock(root, "Ambientes sonoros", "Toque em um dos efeitos para selecionar.")
        names.forEachIndexed { idx, name ->
            val b = button("${if (idx == dsp.preset) "●" else "○"}  $name") {
                dsp.preset = idx
                Toast.makeText(this, "Efeito: $name", Toast.LENGTH_SHORT).show()
                drawUi()
            }
            b.background = shape(if (idx == dsp.preset) purple else Color.rgb(67,44,100), 12f)
            presets.addView(b, LinearLayout.LayoutParams(-1,dp(46)).apply { bottomMargin = dp(6) })
        }
        val controls = addBlock(root,"Mesa de efeitos", "Ajustes processados em tempo real; comece com volume baixo.")
        slider(controls,"Intensidade", dsp.intensity) { dsp.intensity=it }
        slider(controls,"Graves", dsp.bass) { dsp.bass=it }
        slider(controls,"Eco / reverberação", dsp.wet) { dsp.wet=it }
        slider(controls,"Volume processado", dsp.output) { dsp.output=it }
        controls.addView(button("Restaurar ajustes") {
            dsp.intensity=.72f; dsp.bass=.5f; dsp.wet=.35f; dsp.output=.55f; drawUi()
        }, LinearLayout.LayoutParams(-1,dp(46)))

        val local = addBlock(root,"Música do celular", "Abra um arquivo WAV PCM 16-bit estéreo (44,1 ou 48 kHz) para aplicar os efeitos diretamente, sem depender de outro aplicativo.")
        local.addView(button("Abrir arquivo WAV") {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).setType("audio/*").addCategory(Intent.CATEGORY_OPENABLE)
            startActivityForResult(i, REQUEST_WAV)
        },LinearLayout.LayoutParams(-1,dp(48)))
        local.addView(button("Parar música local") { localPlay = false },LinearLayout.LayoutParams(-1,dp(48)).apply { topMargin=dp(8) })

        val help = addBlock(root,"YouTube e Spotify", "O ClubFa não consegue aplicar efeitos diretamente ao áudio de vídeos incorporados ou forçar o desbloqueio da captura. Você pode abrir seus apps para ouvir normalmente.")
        help.addView(button("Abrir YouTube") { openUrl("https://m.youtube.com") }, LinearLayout.LayoutParams(-1,dp(46)))
        help.addView(button("Abrir Spotify") { openUrl("https://open.spotify.com") }, LinearLayout.LayoutParams(-1,dp(46)).apply { topMargin=dp(8) })
        root.addView(text("ClubFa • versão experimental 1.0  |  Sem servidor e sem coleta de áudio",11f,muted))
    }
    private fun slider(card: LinearLayout, name: String, initial: Float, changed: (Float) -> Unit) {
        val title = text("$name · ${(initial*100).toInt()}%",13f)
        card.addView(title)
        card.addView(SeekBar(this).apply {
            max=100; progress=(initial*100).toInt()
            progressTintList=android.content.res.ColorStateList.valueOf(purple)
            thumbTintList=android.content.res.ColorStateList.valueOf(purple)
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb:SeekBar?, value:Int, fromUser:Boolean) { changed(value/100f); title.text="$name · $value%" }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
    }
    private fun openUrl(url:String) { startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(url))) }
    private fun requestCapture() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_AUDIO)
        } else launchCapture()
    }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if (requestCode==REQUEST_AUDIO && grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED) launchCapture()
        else Toast.makeText(this,"Permissão de áudio necessária",Toast.LENGTH_LONG).show()
    }
    private fun launchCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }
    override fun onActivityResult(requestCode:Int, resultCode:Int, data:Intent?) {
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==REQUEST_CAPTURE && resultCode==RESULT_OK && data!=null) {
            val i=Intent(this,CaptureService::class.java).setAction(CaptureService.ACTION_START)
                .putExtra(CaptureService.EXTRA_RESULT,resultCode)
                .putExtra(CaptureService.EXTRA_DATA,data)
            startForegroundService(i)
            Toast.makeText(this,"Captura solicitada. Verifique a notificação.",Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({ if(!isFinishing) drawUi() },1200)
        }
        if(requestCode==REQUEST_WAV && resultCode==RESULT_OK && data?.data!=null) playWav(data.data!!)
    }
    private fun stopCapture() {
        startService(Intent(this,CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
        Handler(Looper.getMainLooper()).postDelayed({ if(!isFinishing) drawUi() },300)
    }
    private fun playWav(uri: Uri) {
        if (localPlay) { Toast.makeText(this,"Pare a música anterior primeiro",Toast.LENGTH_SHORT).show(); return }
        localPlay=true
        localThread=thread(name="ClubFa-WAV") {
            var player: AudioTrack?=null
            try {
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input)
                    val h=ByteArray(12)
                    require(input.read(h)==12 && String(h,0,4)=="RIFF" && String(h,8,4)=="WAVE") { "O arquivo não é WAV" }
                    fun uint32(a:ByteArray, off:Int):Int = (a[off].toInt() and 255) or ((a[off+1].toInt() and 255) shl 8) or ((a[off+2].toInt() and 255) shl 16) or ((a[off+3].toInt() and 255) shl 24)
                    fun uint16(a:ByteArray, off:Int):Int = (a[off].toInt() and 255) or ((a[off+1].toInt() and 255) shl 8)
                    var rate=0; var stereo=false; var bits=0; var codec=0
                    var dataSize=0
                    while (true) {
                        val c=ByteArray(8)
                        if(input.read(c)!=8) break
                        val tag=String(c,0,4)
                        val size=uint32(c,4)
                        require(size in 0..500_000_000) { "WAV inválido" }
                        if(tag=="fmt ") {
                            val fmt=ByteArray(size.coerceAtMost(128))
                            require(input.read(fmt)==fmt.size && fmt.size>=16)
                            codec=uint16(fmt,0); stereo=uint16(fmt,2)==2
                            rate=uint32(fmt,4); bits=uint16(fmt,14)
                            var remain=size-fmt.size
                            while(remain>0) { val skipped=input.skip(remain.toLong()); if(skipped<=0) break; remain-=skipped.toInt() }
                        } else if(tag=="data") { dataSize=size; break }
                        else {
                            var remain=size.toLong()
                            while(remain>0){ val skipped=input.skip(remain); if(skipped<=0) break; remain-=skipped }
                        }
                        if(size%2!=0) input.read()
                    }
                    require(codec==1 && stereo && bits==16 && rate in listOf(44100,48000) && dataSize>0) { "Use WAV PCM16 estéreo em 44,1 ou 48 kHz" }
                    val fmt=AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build()
                    player=AudioTrack.Builder().setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                        .setAllowedCapturePolicy(AudioAttributes.ALLOW_CAPTURE_BY_NONE).build())
                        .setAudioFormat(fmt).setBufferSizeInBytes(maxOf(16384, AudioTrack.getMinBufferSize(rate,AudioFormat.CHANNEL_OUT_STEREO,AudioFormat.ENCODING_PCM_16BIT)*2))
                        .setTransferMode(AudioTrack.MODE_STREAM).build()
                    val engine=Dsp(rate)
                    player!!.play()
                    var remain=dataSize
                    val buf=ByteArray(8192)
                    while(localPlay && remain>0) {
                        val count=input.read(buf,0,minOf(buf.size,remain))
                        if(count<=0) break
                        remain-=count
                        val n=(count/4)*2
                        val shorts=ShortArray(n)
                        var j=0
                        while(j<n) { val k=j*2; shorts[j]=((buf[k].toInt() and 255) or (buf[k+1].toInt() shl 8)).toShort(); j++ }
                        engine.preset=dsp.preset; engine.intensity=dsp.intensity; engine.bass=dsp.bass; engine.wet=dsp.wet; engine.output=dsp.output
                        engine.process(shorts,n)
                        player!!.write(shorts,0,n,AudioTrack.WRITE_BLOCKING)
                    }
                }
            } catch(e:Exception) {
                runOnUiThread { Toast.makeText(this,"Erro no WAV: ${e.localizedMessage}",Toast.LENGTH_LONG).show() }
            } finally {
                localPlay=false
                try { player?.stop(); player?.release() } catch(_:Exception){}
            }
        }
    }
    override fun onDestroy() { localPlay=false; super.onDestroy() }
}
