package com.clubfa.app

import kotlin.math.*

/** Single-thread stereo PCM16 processor; no allocations during callback. */
class Dsp(private val sampleRate: Int = 48000) {
    @Volatile var preset = 0
    @Volatile var intensity = 0.72f
    @Volatile var bass = 0.5f
    @Volatile var wet = 0.35f
    @Volatile var output = 0.55f
    private val delayL = FloatArray(sampleRate * 2)
    private val delayR = FloatArray(sampleRate * 2)
    private var pos = 0
    private var lpL = 0f
    private var lpR = 0f
    private var lowL = 0f
    private var lowR = 0f
    private var outL = 0f
    private var outR = 0f
    private var lastPreset = -1

    fun reset() {
        delayL.fill(0f); delayR.fill(0f)
        lpL=0f; lpR=0f; lowL=0f; lowR=0f; outL=0f; outR=0f; pos=0
    }

    fun process(pcm: ShortArray, n: Int) {
        val p = preset.coerceIn(0, 7)
        if (p != lastPreset) { reset(); lastPreset = p }
        val drive = intensity.coerceIn(0f, 1f)
        val bassAmt = bass.coerceIn(0f, 1f)
        val wetAmt = wet.coerceIn(0f, 1f)
        val volume = output.coerceIn(0f, 1f)
        val cutoff = when(p) { 1 -> 520f; 2 -> 900f; 3 -> 2500f; 4 -> 1600f; 5 -> 720f; 6 -> 3800f; else -> 15000f }
        val a = (1.0 - exp(-2.0 * PI * cutoff / sampleRate)).toFloat()
        val b = (1.0 - exp(-2.0 * PI * 125.0 / sampleRate)).toFloat()
        val echoMs = when(p) { 1 -> 72; 2 -> 145; 3 -> 105; 4 -> 310; 5 -> 44; 6 -> 220; 7 -> 390; else -> 190 }
        val delaySamples = (sampleRate * echoMs / 1000).coerceIn(1, delayL.size - 1)
        val feedback = (when(p) { 1 -> .23f; 4 -> .40f; 7 -> .44f; else -> .17f } * drive).coerceAtMost(.48f)
        val mix = wetAmt * drive * if (p == 0) 0f else .65f
        val wantedBass = bassAmt * if (p == 3 || p == 5) .65f else .33f
        var i = 0
        while (i + 1 < n) {
            val xL = pcm[i] / 32768f
            val xR = pcm[i+1] / 32768f
            lpL += a * (xL - lpL); lpR += a * (xR - lpR)
            lowL += b * (xL - lowL); lowR += b * (xR - lowR)
            val filteredL = xL + (lpL - xL) * drive * if(p==0) 0f else 1f
            val filteredR = xR + (lpR - xR) * drive * if(p==0) 0f else 1f
            val sourceL = (filteredL + lowL * wantedBass).coerceIn(-1f, 1f)
            val sourceR = (filteredR + lowR * wantedBass).coerceIn(-1f, 1f)
            val tap = (pos - delaySamples + delayL.size) % delayL.size
            val tailL = delayL[tap]; val tailR = delayR[tap]
            delayL[pos] = (sourceL + tailR * feedback).coerceIn(-1f,1f)
            delayR[pos] = (sourceR + tailL * feedback).coerceIn(-1f,1f)
            pos = (pos + 1) % delayL.size
            val yL = (sourceL * (1 - mix * .42f) + tailL * mix) * volume
            val yR = (sourceR * (1 - mix * .42f) + tailR * mix) * volume
            // Smooth peak protection to reduce crackles (not a true lookahead limiter).
            outL += .3f * (yL - outL); outR += .3f * (yR - outR)
            pcm[i] = (tanh(outL.toDouble() * 1.1) * 32760).toInt().coerceIn(-32768,32767).toShort()
            pcm[i+1] = (tanh(outR.toDouble() * 1.1) * 32760).toInt().coerceIn(-32768,32767).toShort()
            i += 2
        }
    }
}
