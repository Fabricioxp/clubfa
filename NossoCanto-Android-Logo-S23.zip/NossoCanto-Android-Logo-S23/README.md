# Nosso Canto Android — Logo + correção Galaxy S23

- Ícone recortado e aplicado no AndroidManifest.xml.
- WebView respeita os insets da barra superior, câmera e barra de navegação no Android 15+.
- Ao abrir o teclado, o conteúdo ajusta o espaço disponível.
- O site continua carregando do GitHub Pages e precisa de internet.
- Projeto não compilado nem testado em aparelho nesta entrega.

Para usar no repositório `clubfa`, envie o ZIP inteiro e substitua o workflow
pelo conteúdo de `build-apk-icone-s23.yml` disponibilizado separadamente.
