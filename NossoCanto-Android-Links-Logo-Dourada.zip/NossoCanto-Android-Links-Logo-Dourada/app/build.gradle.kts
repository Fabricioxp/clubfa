plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace = "com.nossocanto.app"
 compileSdk = 35
 defaultConfig { applicationId = "com.nossocanto.app"; minSdk = 24; targetSdk = 35; versionCode = 4; versionName = "1.3" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 kotlinOptions { jvmTarget = "17" }
}
