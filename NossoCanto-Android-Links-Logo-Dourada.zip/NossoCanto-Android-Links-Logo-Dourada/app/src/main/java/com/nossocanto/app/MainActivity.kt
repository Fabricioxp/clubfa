package com.nossocanto.app

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.webkit.CookieManager
import android.webkit.WebSettings
import android.webkit.WebResourceRequest
import android.util.Base64
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.PermissionRequest
import android.widget.FrameLayout
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private val fileRequest = 1102
    private val home = "https://fabricioxp.github.io/nosso-canto/index.html"
    private var pendingPermission: PermissionRequest? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(25, 14, 34)
        window.navigationBarColor = android.graphics.Color.rgb(25, 14, 34)
        web = WebView(this)
        val container = FrameLayout(this)
        container.addView(web, FrameLayout.LayoutParams(-1, -1))
        // Android 15 (incluindo Galaxy S23): respeitar barra de status,
        // recorte da câmera, barra de navegação e teclado.
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            container.setOnApplyWindowInsetsListener { view, insets ->
                val system = insets.getInsets(
                    WindowInsets.Type.systemBars() or WindowInsets.Type.displayCutout()
                )
                val keyboard = insets.getInsets(WindowInsets.Type.ime())
                view.setPadding(
                    system.left,
                    system.top,
                    system.right,
                    maxOf(system.bottom, keyboard.bottom)
                )
                insets
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = 0
        }
        setContentView(container)
        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            javaScriptCanOpenWindowsAutomatically = false
            // target=_blank deve navegar na WebView principal, sem popups temporarios.
            setSupportMultipleWindows(false)
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase()
                if (scheme == "http" || scheme == "https") {
                    // Manter TODAS as páginas do Nosso Canto dentro da mesma WebView.
                    // Não redirecionar para index.html nem recriar a Activity.
                    return false
                }
                return try {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                    true
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Não foi possível abrir o link", Toast.LENGTH_SHORT).show()
                    true
                }
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                // Gravar cookies depois de cada página para manter a sessão.
                CookieManager.getInstance().flush()
                // Adiciona a marca à tela de login do site, sem alterar o Firebase.
                // A correção definitiva do flash de autenticação exige ajuste no index.html.
                if (url?.startsWith("https://fabricioxp.github.io/nosso-canto/") == true &&
                    (url.endsWith("/index.html") || url.endsWith("/nosso-canto/"))) {
                    addLoginLogo()
                }
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(webView: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    startActivityForResult(params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }, fileRequest)
                    true
                } catch (_: ActivityNotFoundException) { fileCallback = null; false }
            }
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val allowed = request.origin.toString().startsWith("https://fabricioxp.github.io/")
                    if (!allowed) { request.deny(); return@runOnUiThread }
                    val needs = mutableListOf<String>()
                    if (request.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needs.add(Manifest.permission.RECORD_AUDIO)
                    if (request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) && checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) needs.add(Manifest.permission.CAMERA)
                    if (needs.isNotEmpty()) { pendingPermission = request; requestPermissions(needs.toTypedArray(), 2201) }
                    else request.grant(request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE || it == PermissionRequest.RESOURCE_VIDEO_CAPTURE }.toTypedArray())
                }
            }
        }
        if (savedInstanceState != null) {
            val restored = web.restoreState(savedInstanceState)
            if (restored == null) web.loadUrl(home)
        } else {
            web.loadUrl(home)
        }
    }
    private fun addLoginLogo() {
        try {
            val bytes = assets.open("logo_login.jpg").use { it.readBytes() }
            val data = "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
            val script = """
                (function(){
                  function applyLogo(){
                    var login = document.querySelector('#tela-login .box-login');
                    if (!login || login.querySelector('#nosso-canto-logo-app')) return;
                    var img = document.createElement('img');
                    img.id='nosso-canto-logo-app';
                    img.alt='Nosso Canto';
                    img.src='$data';
                    img.style.cssText='display:block;width:112px;height:112px;object-fit:cover;border-radius:24px;margin:0 auto 16px;';
                    login.insertBefore(img,login.firstChild);
                  }
                  applyLogo();
                  if (!window.__ncLogoObserver) {
                    window.__ncLogoObserver = new MutationObserver(applyLogo);
                    window.__ncLogoObserver.observe(document.documentElement,{childList:true,subtree:true});
                  }
                })();
            """.trimIndent()
            web.evaluateJavascript(script, null)
        } catch (_: Exception) { }
    }

    @Deprecated("Android back navigation")
    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 2201) {
            val request = pendingPermission ?: return
            pendingPermission = null
            if (grantResults.all { it == PackageManager.PERMISSION_GRANTED }) request.grant(request.resources.filter { it == PermissionRequest.RESOURCE_AUDIO_CAPTURE || it == PermissionRequest.RESOURCE_VIDEO_CAPTURE }.toTypedArray())
            else request.deny()
        }
    }
    @Deprecated("Legacy activity result for WebView file chooser")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileRequest) {
            fileCallback?.onReceiveValue(if (resultCode == Activity.RESULT_OK) WebChromeClient.FileChooserParams.parseResult(resultCode, data) else null)
            fileCallback = null
        }
    }
    override fun onSaveInstanceState(outState: Bundle) { web.saveState(outState); super.onSaveInstanceState(outState) }
    override fun onDestroy() { web.destroy(); super.onDestroy() }
}
