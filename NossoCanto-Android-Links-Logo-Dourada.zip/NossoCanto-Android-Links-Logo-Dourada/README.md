# Nosso Canto Android v1.3

- Links com `target="_blank"` agora usam a WebView principal (`setSupportMultipleWindows(false)`). Isso elimina a janela temporária que podia retornar à página inicial.
- Ícone com fundo azul/roxo escuro e título dourado.
- Logo injetada visualmente no formulário de login do `index.html` carregado no APK (sem modificar o site hospedado).
- Mantém os ajustes de margens para a câmera e barras do Galaxy S23.
- **Não altera a autenticação Firebase**. Para eliminar o flash de login em recargas, a correção definitiva deve ser feita no `index.html` do site, aguardando o estado de autenticação antes de mostrar o formulário.
- Ainda não compilado nem testado em aparelho.
