# Nosso Canto Android — Navegação v1.2

Correções:
- Navegação HTTP/HTTPS permanece na mesma WebView.
- Links target=_blank podem abrir na WebView principal.
- Cookies gravados ao fim de cada carregamento.
- Restauração do estado WebView ao recriar a Activity.
- Mantidos ícone Nosso Canto e ajustes de insets Galaxy S23.

IMPORTANTE: O login do site é controlado pelo próprio JavaScript/Firebase do site.
Se o login aparecer brevemente em cada navegação, é necessário ajustar no
repositório `nosso-canto` a renderização inicial da tela de autenticação,
mantendo uma tela neutra de carregamento até `onAuthStateChanged` concluir.
O wrapper Android sozinho não garante eliminar esse flash.

Não compilado nem testado em dispositivo Android nesta entrega.
