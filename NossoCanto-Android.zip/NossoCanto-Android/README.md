# Nosso Canto — Android

Aplicativo Android WebView para `https://fabricioxp.github.io/nosso-canto/`.

## Como compilar pelo celular
1. Crie um repositório GitHub para o app (separado do site).
2. Envie todos os arquivos e pastas deste ZIP à raiz do repositório (inclusive `.github`).
3. Em Actions, execute `Nosso Canto - Gerar APK`.
4. Baixe o artefato `Nosso-Canto-APK` e instale `app-debug.apk`.

## Limites
- Este app abre o site publicado pela internet; não inclui cópia offline do site.
- A URL padrão do GitHub Pages foi inferida; se o site usar domínio personalizado, altere `home` em `MainActivity.kt`.
- APIs do navegador, OAuth, notificações push e downloads específicos podem precisar de adaptação adicional.
- Não foi compilado nem testado em dispositivo Android neste ambiente.
